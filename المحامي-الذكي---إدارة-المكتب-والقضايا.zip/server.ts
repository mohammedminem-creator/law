import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '30mb' }));

// Persistent Multi-Device Server Database Path
const DATA_DIR = path.resolve(__dirname, 'server-data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Default initial state for Mr. Eslam Omar Korany law office
const defaultInitialState = {
  profile: {
    lawyerName: 'الأستاذ / إسلام عمر قرني',
    title: 'محامٍ - 15 عاماً من الخبرة',
    firmName: 'مكتب محاماه الأستاذ / إسلام عمر قرني',
    phone: '01006580460',
    secondaryPhone: '01558866646',
    email: 'eslam.omar.law@gmail.com',
    address: 'جمهورية مصر العربية',
    barNumber: 'مقيد بنقابة المحامين',
    slogan: 'في خدمة العدالة والدفاع عن حقوقكم .. معكم في كل قضية',
    experienceYears: 15,
    specializations: [
      'قضايا مدنية',
      'قضايا جنائية',
      'أحوال شخصية',
      'استشارات قانونية',
    ],
    logoUrl: '/assets/aistudio/____________________________a39fbca1.png',
  },
  security: {
    pinEnabled: false,
    pinCode: '1234',
    autoLockMinutes: 15,
  },
  cases: [],
  sessions: [],
  documents: [],
  payments: [],
  expenses: [],
  clients: [],
  consultations: [],
  version: 1,
  lastModified: new Date().toISOString(),
};

// Ensure data directory and db file exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

let serverMemoryDb = defaultInitialState;

if (fs.existsSync(DB_FILE)) {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    serverMemoryDb = JSON.parse(raw);
    // Ensure profile contains Eslam Omar Korany info
    if (serverMemoryDb.profile?.lawyerName !== 'الأستاذ / إسلام عمر قرني') {
      serverMemoryDb.profile = defaultInitialState.profile;
      fs.writeFileSync(DB_FILE, JSON.stringify(serverMemoryDb, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Failed reading existing DB file, using default:', err);
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultInitialState, null, 2), 'utf-8');
  }
} else {
  fs.writeFileSync(DB_FILE, JSON.stringify(defaultInitialState, null, 2), 'utf-8');
}

// Helper to save DB to disk
function persistDb(data: any) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write db.json:', err);
  }
}

// GET /api/data - Get current state across all connected devices
app.get('/api/data', (_req, res) => {
  res.json({
    data: serverMemoryDb,
    version: serverMemoryDb.version || 1,
    lastModified: serverMemoryDb.lastModified || new Date().toISOString(),
  });
});

// GET /api/data/version - Lightweight check for changes from other devices
app.get('/api/data/version', (_req, res) => {
  res.json({
    version: serverMemoryDb.version || 1,
    lastModified: serverMemoryDb.lastModified || new Date().toISOString(),
  });
});

// POST /api/data - Save state from any device and broadcast version
app.post('/api/data', (req, res) => {
  try {
    const incomingData = req.body.data;
    if (!incomingData) {
      return res.status(400).json({ error: 'Missing data in payload' });
    }

    const nextVersion = (serverMemoryDb.version || 1) + 1;
    const now = new Date().toISOString();

    serverMemoryDb = {
      ...incomingData,
      version: nextVersion,
      lastModified: now,
    };

    persistDb(serverMemoryDb);

    return res.json({
      success: true,
      version: nextVersion,
      lastModified: now,
    });
  } catch (err: any) {
    console.error('Error saving server data:', err);
    return res.status(500).json({ error: err?.message || 'Server save failed' });
  }
});

// POST /api/data/reset - Reset to clean production state
app.post('/api/data/reset', (_req, res) => {
  serverMemoryDb = {
    ...defaultInitialState,
    version: (serverMemoryDb.version || 1) + 1,
    lastModified: new Date().toISOString(),
  };
  persistDb(serverMemoryDb);
  return res.json({ success: true, data: serverMemoryDb });
});

// Helper to get GoogleGenAI instance safely
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
}

// AI Legal Assistant API
app.post('/api/ai/legal-assistant', async (req, res) => {
  try {
    const { action, caseData, query, context } = req.body;
    const ai = getGenAI();

    let prompt = '';
    const lawyerHeader = `المحامي: الأستاذ / إسلام عمر قرني (خبرة 15 عاماً في المحاماة والاستشارات القانونية)`;
    const caseSummary = caseData
      ? `
${lawyerHeader}
بيانات القضية:
- رقم القضية: ${caseData.caseNumber || '---'} لسنة ${caseData.year || '---'}
- النوع: ${caseData.caseType || '---'}
- المحكمة: ${caseData.court || '---'} (${caseData.circuit || 'الدائرة'})
- الموكل: ${caseData.clientName || '---'} (${caseData.clientRole || 'صفة الموكل'})
- الخصم: ${caseData.opponentName || '---'} (محاميه: ${caseData.opponentLawyer || 'غير محدد'})
- موضوع النزاع: ${caseData.subject || '---'}
- آخر قرار أو تأجيل: ${caseData.latestDecision || '---'}
- ملاحظات وتفاصيل الوقائع: ${caseData.notes || '---'}
`
      : '';

    switch (action) {
      case 'draft_memo':
        prompt = `أنت مستشار قانوني ومحامٍ نقض خبير في القوانين والمرافعات القضائية المصرية والعربية.
صغ مذكرة دفاع رسمية لمحكمة الموضوع باسم: مكتب محاماه الأستاذ / إسلام عمر قرني.
${caseSummary}
ملاحظات إضافية من المحامي: ${query || 'لا يوجد'}

يرجى صياغة المذكرة بالشكل القضائي الاحترافي المتكامل:
1. الديباجة الرسمية (أمام محكمة / الدائرة / أسماء الأطراف وصفاتهم).
2. الوقائع بإيجاز وتسلسل منطقي مقنع.
3. الدفوع القانونية وأوجه الدفاع (تأصيل نصوص القانون وأحكام النقض المستقرة).
4. الرد المفند لادعاءات الخصم.
5. الطلبات الختامية الجازمة (أصلياً واحتياطياً).
استخدم لغة قانونية عربية فصحى وبليغة تليق بساحات القضاء.`;
        break;

      case 'draft_lawsuit':
        prompt = `أنت محامٍ بارع. المطلوب صياغة "عريضة دعوى قضائية / صحيفة افتتاح دعوى" أو "إنذار رسمي على يد محضر":
باسم: مكتب محاماه الأستاذ / إسلام عمر قرني
${caseSummary}
الطلبات المطلوبة: ${query || 'إلزام الخصم بالحقوق المترتبة مع المصاريف وأتعاب المحاماة'}

صغ العريضة بالصيغة الإجرائية المعتمدة لمحاضر الإعلان:
- ديباجة الإعلان على يد محضر.
- بناءً على طلب الطالب وتكليف الخصم بالحضور.
- الموضوع والوقائع.
- السند القانوني والنصوص الحاكمة.
- بناءً عليه وتحديد موعد الجلسة والطلبات.`;
        break;

      case 'suggest_defenses':
        prompt = `بصفتك باحثاً ومستشاراً قانونياً رفيع المستوى لدى مكتب محاماه الأستاذ / إسلام عمر قرني، حلل هذه الدعوى واقترح أهم "الدفوع الشكلية والموضوعية" المحتملة والمفيدة لموقف موكلنا:
${caseSummary}
السؤال أو التوجيه: ${query || 'اقترح دفوعاً قانونية قوية'}

قدم الدفوع مقسمة بوضوح:
1. دفوع شكلية وإجرائية (مثل الاختصاص، الميعاد، الصفة، المصلحة، بطلان الإعلان).
2. دفوع موضوعية (مثل انعدام السند، الإبراء، عدم الصحة، التقادم، حجية الأحكام).
3. أدلة ومستندات يُنصح بتقديمها لتدعيم الدفع.`;
        break;

      case 'whatsapp_update':
        prompt = `صغ رسالة موجزة، واضحة ومطمئنة لإرسالها للموكل عبر تطبيق "واتساب" لإبلاغه بآخر مستجدات قضيته أو موعد الجلسة والتأجيل:
باسم: مكتب محاماه الأستاذ / إسلام عمر قرني (هاتف: 01006580460 - 01558866646)
${caseSummary}
الرسالة الإضافية أو قرار الجلسة: ${query || 'تم تأجيل الجلسة لاتخاذ الإجراءات اللازمة'}

شروط الرسالة:
- تبدأ بعبارة ترحيبية راقية ومهنية باسم مكتب الأستاذ إسلام عمر قرني.
- تذكر رقم القضية والمحكمة بوضوح.
- تذكر موعد الجلسة القادمة والسبب باختصار غير مخل ومطمئن للموكل.
- لا تتجاوز 4 إلى 5 أسطر سهلة القراءة.`;
        break;

      case 'legal_consultation':
      default:
        prompt = `أنت مساعد قانوني ذكي لمكتب محاماه الأستاذ / إسلام عمر قرني (خبرة 15 عاماً). أجب عن استفسار المحامي التالي باحترافية وتأصيل قانوني:
${caseSummary ? 'سياق القضية:\n' + caseSummary : ''}
استفسار المحامي / المسألة: ${query || context || 'طلب استشارة قانونية عامة'}

قدّم تحليلاً عملياً، الخطوات الإجرائية المطلوبة، والنصائح الاحترازية للمكتب.`;
        break;
    }

    if (!ai) {
      const fallbackResponse = generateLocalFallback(action, caseData, query);
      return res.json({ text: fallbackResponse, isFallback: true });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    const responseText = response.text || 'لم يتم استلام نص من النموذج.';
    return res.json({ text: responseText, isFallback: false });
  } catch (error: any) {
    console.error('Error in AI Legal Assistant endpoint:', error);
    const { action, caseData, query } = req.body || {};
    const fallbackText = generateLocalFallback(action, caseData, query);
    return res.json({
      text: fallbackText,
      isFallback: true,
      error: error?.message || 'تم استخدام النموذج المحلي المؤقت',
    });
  }
});

// Professional local legal fallback generator
function generateLocalFallback(action: string, caseData: any, query?: string): string {
  const cNum = caseData?.caseNumber || '---';
  const cYear = caseData?.year || new Date().getFullYear();
  const cCourt = caseData?.court || 'المحكمة المختصة';
  const cClient = caseData?.clientName || 'الموكل الموقر';
  const cOpponent = caseData?.opponentName || 'الخصم';
  const cRole = caseData?.clientRole || 'مدعي/مدعى عليه';

  if (action === 'draft_memo') {
    return `مذكـــــرة دفـــــاع
مقدمة من: مكتب محاماه الأستاذ / إسلام عمر قرني
إلى: محكمة ${cCourt} الموقرة (${caseData?.circuit || 'الدائرة المختصة'})
في القضية رقم: ${cNum} لسنة ${cYear}
المحدد لنظرها جلسة: ${caseData?.latestDate || 'المقبلة'}

باسم: ${cClient} (صفته: ${cRole})
ضـــد: ${cOpponent} (الخصم)

أولاً: الوقائع:
تتحصل وقائع هذه الدعوى في أن الموكل قد أقام علاقته وسنده وفقاً لما تضمنته الأوراق وصحيفة الدعوى، إلا أن الخصم قد خالف ما استقرت عليه العقود والأصول القانونية الثابتة.

ثانياً: الدفوع وأوجه الدفاع القانونية:
1. الدفع بعدم قبول الدعوى لرفعها من غير ذي صفة أو مصلحة (طبقاً لقواعد المرافعات).
2. الدفع بخلو الأوراق من ثمة دليل يقيني يعتد به لإثبات ادعاءات الخصم.
3. الثابت بالمستندات المرفقة بحافظتنا سداد كامل الالتزامات ونفي أي إخلال.

ثالثاً: الطلبات الختامية:
يلتمس الحاضر عن ${cRole} القضاء:
أصلياً: برفض الدعوى وإلزام رافعها بالمصروفات ومقابل أتعاب المحاماة.
احتياطياً: بندب خبير في الدعوى لتحقيق عناصر النزاع وبيان وجه الحق.
مع حفظ كافة الحقوق القانونية الأخرى للموكل.

وكيل ${cRole}
الأستاذ / إسلام عمر قرني
المحامي
هاتف: 01006580460 - 01558866646`;
  }

  if (action === 'whatsapp_update') {
    return `السلام عليكم ورحمة الله وبركاته،
أهلاً بحضرتك أ/ ${cClient}،
تحية طيبة من مكتب محاماه الأستاذ / إسلام عمر قرني.
نحيط علم سيادتكم بمستجدات قضيتكم رقم (${cNum} لسنة ${cYear}) أمام (${cCourt}):
- تم تأجيل الجلسة إلى تاريخ: ${caseData?.latestDate || 'الجلسة القادمة'}
- سبب التأجيل: ${query || caseData?.latestDecision || 'لاتخاذ الإجراءات واستيفاء المستندات اللازمة في صالح القضية'}.
مكتبنا يتابع الإجراءات بكل عناية، وسنوافيكم بأي تطورات أولاً بأول.
هاتف: 01006580460 / 01558866646
معكم .. في كل قضية.`;
  }

  return `تحليل قانوني مقترح للدعوى رقم ${cNum} لسنة ${cYear}:
مكتب الأستاذ / إسلام عمر قرني:
1. فحص الإعلانات وإجراءات قيد الدعوى للتأكد من صحة الخصومة وانعقادها.
2. تجهيز حافظة مستندات مرتبة ومفهرسة تشمل العقود والمكاتبات المتبادلة.
3. إبداء الدفوع الإجرائية في أول جلسة مرافعة قبل الدخول في الموضوع حماية للموقف الإجرائي.`;
}

// Development with Vite vs Production static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Smart Lawyer backend running on port ${PORT}`);
  });
}

startServer();
