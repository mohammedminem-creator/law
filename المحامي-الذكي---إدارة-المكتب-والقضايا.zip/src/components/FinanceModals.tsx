import React, { useState } from 'react';
import { X, DollarSign, Receipt, Plus } from 'lucide-react';
import { PaymentRecord, ExpenseRecord, CaseItem } from '../types/legal';

interface NewPaymentModalProps {
  cases: CaseItem[];
  defaultCaseId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSave: (payment: PaymentRecord) => void;
}

export const NewPaymentModal: React.FC<NewPaymentModalProps> = ({
  cases,
  defaultCaseId,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [caseId, setCaseId] = useState(defaultCaseId || cases[0]?.id || '');
  const [amount, setAmount] = useState<number>(5000);
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentRecord['paymentMethod']>('نقدي');
  const [receiptNumber, setReceiptNumber] = useState(
    () => `REC-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`
  );
  const [receivedBy, setReceivedBy] = useState('إدارة الحسابات بالمكتب');
  const [notes, setNotes] = useState('');

  const selectedCase = cases.find(c => c.id === caseId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseId || amount <= 0) return;

    const newPayment: PaymentRecord = {
      id: 'pay-' + Date.now(),
      caseId,
      amount: Number(amount),
      date,
      paymentMethod,
      receiptNumber,
      receivedBy,
      notes: notes.trim() || undefined,
    };

    onSave(newPayment);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 overflow-y-auto">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 text-right">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                تسجيل دفعة أتعاب جديدة
              </h3>
              <p className="text-[11px] text-slate-500">إصدار سند قبض وإيداع بالخزينة</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              القضية / الموكل *
            </label>
            <select
              required
              value={caseId}
              onChange={e => setCaseId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            >
              {cases.map(c => (
                <option key={c.id} value={c.id}>
                  قضية {c.caseNumber}/{c.year} - {c.clientName} ({c.court})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                المبلغ المدفوع (ج.م) *
              </label>
              <input
                type="number"
                min="100"
                step="100"
                required
                value={amount}
                onChange={e => setAmount(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                تاريخ القبض *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                طريقة الدفع
              </label>
              <select
                value={paymentMethod}
                onChange={e => setPaymentMethod(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              >
                <option value="نقدي">نقدي (كاش)</option>
                <option value="محفظة إلكترونية / إنستاباي">إنستاباي / محفظة</option>
                <option value="تحويل بنكي">تحويل بنكي</option>
                <option value="شيك مصرفي">شيك مصرفي</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                رقم سند القبض
              </label>
              <input
                type="text"
                required
                value={receiptNumber}
                onChange={e => setReceiptNumber(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              ملاحظات أو بيان الدفعة
            </label>
            <input
              type="text"
              placeholder="مثال: دفعة ثانية بعد المرافعة..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm"
            >
              حفظ وإصدار السند
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface NewExpenseModalProps {
  cases: CaseItem[];
  defaultCaseId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSave: (expense: ExpenseRecord) => void;
}

export const NewExpenseModal: React.FC<NewExpenseModalProps> = ({
  cases,
  defaultCaseId,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [caseId, setCaseId] = useState(defaultCaseId || cases[0]?.id || '');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<number>(350);
  const [category, setCategory] = useState<ExpenseRecord['category']>('رسوم قضائية');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseId || !title.trim() || amount <= 0) return;

    const newExpense: ExpenseRecord = {
      id: 'exp-' + Date.now(),
      caseId,
      title: title.trim(),
      amount: Number(amount),
      category,
      date,
      notes: notes.trim() || undefined,
    };

    onSave(newExpense);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 overflow-y-auto">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 text-right">
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                تسجيل مصروف / رسوم قضائية
              </h3>
              <p className="text-[11px] text-slate-500">إثبات الرسوم والدمغات وتكاليف المحضرين</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              القضية *
            </label>
            <select
              required
              value={caseId}
              onChange={e => setCaseId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            >
              {cases.map(c => (
                <option key={c.id} value={c.id}>
                  قضية {c.caseNumber}/{c.year} - {c.clientName}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              بيان المصروف *
            </label>
            <input
              type="text"
              required
              placeholder="مثال: رسوم استخراج صورة رسمية، أمانة خبير، إعلان محضرين..."
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                المبلغ (ج.م) *
              </label>
              <input
                type="number"
                min="5"
                step="5"
                required
                value={amount}
                onChange={e => setAmount(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                التصنيف *
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              >
                <option value="رسوم قضائية">رسوم قضائية وخزينة</option>
                <option value="دمغات وتوكيلات">دمغات وتوكيلات</option>
                <option value="إعلانات وتكاليف محضّرين">إعلانات محضّرين</option>
                <option value="أتعاب خبراء">أتعاب وأمانة خبراء</option>
                <option value="انتقالات وسفر">انتقالات وسفر</option>
                <option value="تصوير ونسخ مستندات">تصوير ونسخ مستندات</option>
                <option value="أخرى">أخرى</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              تاريخ الصرف
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              ملاحظات أو رقم الإيصال
            </label>
            <input
              type="text"
              placeholder="مثال: قسيمة سداد رقم 5124..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-sm"
            >
              تسجيل المصروف
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
