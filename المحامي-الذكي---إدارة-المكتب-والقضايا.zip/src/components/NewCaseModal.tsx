import React, { useState } from 'react';
import { X, Briefcase, Plus, User, Building2, Calendar, DollarSign, FileText } from 'lucide-react';
import { CaseItem, CaseType, ClientRole, CourtSession } from '../types/legal';

interface NewCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (newCase: CaseItem, initialSession?: CourtSession, initialPaymentAmount?: number) => void;
}

const CASE_TYPES: CaseType[] = [
  'جنح',
  'جنايات',
  'مدني كلي',
  'مدني جزئي',
  'أسرة (أحوال شخصية)',
  'تجاري وإفلاس',
  'عمالي',
  'مجلس الدولة (قضاء إداري)',
  'محكمة النقض',
  'محكمة الاستئناف',
  'محكمة تنفيذ',
  'أمور وقتية ومستعجلة',
  'أخرى',
];

const CLIENT_ROLES: ClientRole[] = [
  'مدعي',
  'مدعى عليه',
  'مجني عليه',
  'متهم',
  'طالب',
  'مطلوب ضده',
  'مستأنِف',
  'مستأنَف ضده',
  'طاعن',
  'مطعون ضده',
  'شاكي',
  'مشكو في حقه',
];

const COMMON_COURTS = [
  'محكمة جنوب القاهرة الابتدائية',
  'محكمة شمال القاهرة الابتدائية',
  'محكمة جنح مدينة نصر',
  'محكمة أسرة مصر الجديدة',
  'محكمة استئناف القاهرة',
  'محكمة النقض',
  'محكمة القضاء الإداري - مجلس الدولة',
  'المحكمة الاقتصادية بالقاهرة',
  'محكمة الجيزة الابتدائية',
  'محكمة الإسكندرية الابتدائية',
];

export const NewCaseModal: React.FC<NewCaseModalProps> = ({ isOpen, onClose, onSave }) => {
  if (!isOpen) return null;

  const currentYear = new Date().getFullYear();

  // Form states
  const [caseNumber, setCaseNumber] = useState('');
  const [year, setYear] = useState<number>(currentYear);
  const [caseType, setCaseType] = useState<CaseType>('مدني كلي');
  const [court, setCourt] = useState('محكمة جنوب القاهرة الابتدائية');
  const [circuit, setCircuit] = useState('');
  const [judgeName, setJudgeName] = useState('');

  // Client info
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientRole, setClientRole] = useState<ClientRole>('مدعي');
  const [clientAddress, setClientAddress] = useState('');

  // Opponent info
  const [opponentName, setOpponentName] = useState('');
  const [opponentLawyer, setOpponentLawyer] = useState('');
  const [opponentPhone, setOpponentPhone] = useState('');

  // Subject & Notes
  const [subject, setSubject] = useState('');
  const [notes, setNotes] = useState('');

  // Financials
  const [totalFee, setTotalFee] = useState<number>(20000);
  const [advancePayment, setAdvancePayment] = useState<number>(5000);

  // First session option
  const [hasFirstSession, setHasFirstSession] = useState(true);
  const [sessionDate, setSessionDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });
  const [sessionTime, setSessionTime] = useState('10:00');
  const [decisionOrReason, setDecisionOrReason] = useState('أولى جلسات نظر الدعوى وتقديم أصل الصحيفة');
  const [courtroom, setCourtroom] = useState('قاعة 2');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseNumber.trim() || !clientName.trim() || !subject.trim()) return;

    const caseId = 'case-' + Date.now();
    const newCase: CaseItem = {
      id: caseId,
      caseNumber: caseNumber.trim(),
      year: Number(year) || currentYear,
      caseType,
      court: court.trim(),
      circuit: circuit.trim() || undefined,
      judgeName: judgeName.trim() || undefined,
      clientName: clientName.trim(),
      clientPhone: clientPhone.trim(),
      clientEmail: clientEmail.trim() || undefined,
      clientRole,
      clientAddress: clientAddress.trim() || undefined,
      opponentName: opponentName.trim() || 'غير محدد',
      opponentLawyer: opponentLawyer.trim() || undefined,
      opponentPhone: opponentPhone.trim() || undefined,
      subject: subject.trim(),
      status: 'جارية',
      notes: notes.trim() || undefined,
      totalFee: Number(totalFee) || 0,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    let initialSession: CourtSession | undefined = undefined;
    if (hasFirstSession && sessionDate) {
      initialSession = {
        id: 'sess-' + Date.now(),
        caseId: caseId,
        sessionDate,
        sessionTime,
        courtroom,
        chamber: circuit,
        decisionOrReason,
        isCompleted: false,
        postponementHistory: [],
      };
    }

    onSave(newCase, initialSession, Number(advancePayment) || 0);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl my-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 sm:p-7 text-right">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                تسجيل قضية جديدة بالأجندة
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                إدخال بيانات الدعوى، الأطراف، الجلسة الأولى، والأتعاب المتفق عليها
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Section 1: Case Details */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-3 flex items-center gap-1.5">
              <Building2 className="w-4 h-4" />
              <span>1. بيانات المحكمة والقضية</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  رقم القضية *
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: 1042"
                  value={caseNumber}
                  onChange={e => setCaseNumber(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  السنة القضائية *
                </label>
                <input
                  type="number"
                  required
                  value={year}
                  onChange={e => setYear(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  نوع القضية *
                </label>
                <select
                  value={caseType}
                  onChange={e => setCaseType(e.target.value as CaseType)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                >
                  {CASE_TYPES.map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  المحكمة المختصة *
                </label>
                <input
                  type="text"
                  required
                  list="courts-list"
                  placeholder="اسم المحكمة"
                  value={court}
                  onChange={e => setCourt(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
                <datalist id="courts-list">
                  {COMMON_COURTS.map(c => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  الدائرة / القاضي
                </label>
                <input
                  type="text"
                  placeholder="مثال: الدائرة 4 جنح مستأنف"
                  value={circuit}
                  onChange={e => setCircuit(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Parties (Client & Opponent) */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-3 flex items-center gap-1.5">
              <User className="w-4 h-4" />
              <span>2. بيانات الموكل والخصم</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  اسم الموكل *
                </label>
                <input
                  type="text"
                  required
                  placeholder="الاسم الثلاثي أو الرباعي"
                  value={clientName}
                  onChange={e => setClientName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  صفة الموكل في الدعوى *
                </label>
                <select
                  value={clientRole}
                  onChange={e => setClientRole(e.target.value as ClientRole)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                >
                  {CLIENT_ROLES.map(r => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  رقم هاتف الموكل (للواتساب) *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="01xxxxxxxxx"
                  value={clientPhone}
                  onChange={e => setClientPhone(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  اسم الخصم *
                </label>
                <input
                  type="text"
                  required
                  placeholder="اسم الخصم أو الشركة"
                  value={opponentName}
                  onChange={e => setOpponentName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  اسم محامي الخصم (إن وجد)
                </label>
                <input
                  type="text"
                  placeholder="الأستاذ / ..."
                  value={opponentLawyer}
                  onChange={e => setOpponentLawyer(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  عنوان الموكل / الإقامة
                </label>
                <input
                  type="text"
                  placeholder="المدينة، الحي"
                  value={clientAddress}
                  onChange={e => setClientAddress(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Subject & Details */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-3 flex items-center gap-1.5">
              <FileText className="w-4 h-4" />
              <span>3. موضوع الدعوى والملاحظات</span>
            </h4>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  موضوع الدعوى والطلبات الأساسية *
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="شرح موجز لموضوع القضية، مثلاً: دعوى مطالبة بتعويض عن إخلال عقدي بمبلغ 250,000 جنيه..."
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Fees and Advance Payment */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-3 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4" />
              <span>4. الأتعاب المتفق عليها والدفعة المقدمة</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  إجمالي الأتعاب المتفق عليها (ج.م) *
                </label>
                <input
                  type="number"
                  min="0"
                  step="500"
                  required
                  value={totalFee}
                  onChange={e => setTotalFee(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  الدفعة المقدمة المدفوعة الآن (ج.م)
                </label>
                <input
                  type="number"
                  min="0"
                  step="500"
                  value={advancePayment}
                  onChange={e => setAdvancePayment(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  المتبقي سيكون: {Math.max(0, totalFee - advancePayment).toLocaleString()} ج.م (يصدر سند قبض تلقائياً)
                </p>
              </div>
            </div>
          </div>

          {/* Section 5: First Court Session */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                <span>5. موعد أول جلسة في المحكمة</span>
              </h4>
              <label className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasFirstSession}
                  onChange={e => setHasFirstSession(e.target.checked)}
                  className="rounded text-amber-600"
                />
                <span>تحديد موعد جلسة الآن</span>
              </label>
            </div>

            {hasFirstSession && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    تاريخ أول جلسة *
                  </label>
                  <input
                    type="date"
                    required={hasFirstSession}
                    value={sessionDate}
                    onChange={e => setSessionDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    القاعة / الغرفة
                  </label>
                  <input
                    type="text"
                    value={courtroom}
                    onChange={e => setCourtroom(e.target.value)}
                    placeholder="مثال: قاعة 3 مدني"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    سبب أو قرار الجلسة
                  </label>
                  <input
                    type="text"
                    value={decisionOrReason}
                    onChange={e => setDecisionOrReason(e.target.value)}
                    placeholder="سبب الجلسة الأولى"
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-xl transition-all shadow-md shadow-amber-600/20 flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>حفظ وقيد القضية بالأجندة</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
