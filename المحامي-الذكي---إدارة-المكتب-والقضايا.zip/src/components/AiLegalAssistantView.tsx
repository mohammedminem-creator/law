import React, { useState } from 'react';
import {
  Sparkles,
  FileText,
  Copy,
  Printer,
  Check,
  Send,
  MessageSquare,
  Scale,
  FolderPlus,
  RefreshCw,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { CaseItem, LawFirmProfile } from '../types/legal';
import { createWhatsAppUrl } from '../utils/storage';

interface AiLegalAssistantViewProps {
  cases: CaseItem[];
  firmProfile: LawFirmProfile;
  initialCaseId?: string;
  initialAction?: string;
  onSaveDocToCase?: (caseId: string, title: string, text: string) => void;
}

export const AiLegalAssistantView: React.FC<AiLegalAssistantViewProps> = ({
  cases,
  firmProfile,
  initialCaseId,
  initialAction = 'draft_memo',
  onSaveDocToCase,
}) => {
  const [selectedCaseId, setSelectedCaseId] = useState<string>(initialCaseId || cases[0]?.id || '');
  const [action, setAction] = useState<string>(initialAction);
  const [customInstructions, setCustomInstructions] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [generatedText, setGeneratedText] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [isSavedToDocs, setIsSavedToDocs] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedCase = cases.find(c => c.id === selectedCaseId);

  const handleGenerate = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    setIsSavedToDocs(false);

    try {
      const response = await fetch('/api/ai/legal-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          caseData: selectedCase
            ? {
                caseNumber: selectedCase.caseNumber,
                year: selectedCase.year,
                caseType: selectedCase.caseType,
                court: selectedCase.court,
                circuit: selectedCase.circuit,
                clientName: selectedCase.clientName,
                clientRole: selectedCase.clientRole,
                opponentName: selectedCase.opponentName,
                opponentLawyer: selectedCase.opponentLawyer,
                subject: selectedCase.subject,
                notes: selectedCase.notes,
              }
            : null,
          query: customInstructions.trim(),
        }),
      });

      const data = await response.json();
      if (data.text) {
        setGeneratedText(data.text);
      } else {
        setErrorMsg('تعذر استلام نص، يرجى المحاولة مرة أخرى.');
      }
    } catch (err: any) {
      console.error('AI generate error:', err);
      setErrorMsg('حدث خطأ أثناء الاتصال بالخادم الذكي.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!generatedText) return;
    navigator.clipboard.writeText(generatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleSaveToArchive = () => {
    if (!generatedText || !selectedCaseId || !onSaveDocToCase) return;
    const title =
      action === 'draft_memo'
        ? `مسودة مذكرة دفاع - قضية ${selectedCase?.caseNumber}`
        : action === 'draft_lawsuit'
        ? `صحيفة دعوى - قضية ${selectedCase?.caseNumber}`
        : `تحليل واستشارة ذكية - قضية ${selectedCase?.caseNumber}`;

    onSaveDocToCase(selectedCaseId, title, generatedText);
    setIsSavedToDocs(true);
    setTimeout(() => setIsSavedToDocs(false), 3000);
  };

  const handleSendWhatsApp = () => {
    if (!selectedCase?.clientPhone || !generatedText) return;
    window.open(createWhatsAppUrl(selectedCase.clientPhone, generatedText), '_blank');
  };

  return (
    <div className="space-y-5">
      
      {/* Top Banner - Hide on print */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-600" />
            <span>المساعد القانوني الذكي (صياغة المذكرات والدفوع)</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            توليد مذكرات الدفاع، تفنيد ادعاءات الخصوم، صياغة عرائض الدعاوى ورسائل الموكلين التلقائية
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Left Column: Form Controls (Hide on print) */}
        <div className="lg:col-span-1 space-y-4 no-print">
          
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3.5 shadow-xs">
            
            {/* Action selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                نوع المهمة القانونية *
              </label>
              <div className="space-y-1.5">
                {[
                  { id: 'draft_memo', label: 'صياغة مذكرة دفاع متكاملة', desc: 'ديباجة، وقائع، دفوع قانونية، وطلبات' },
                  { id: 'suggest_defenses', label: 'اقتراح الدفوع الشكلية والموضوعية', desc: 'تحليل الثغرات والدفوع الجوهرية' },
                  { id: 'draft_lawsuit', label: 'صياغة عريضة دعوى / إنذار رسمي', desc: 'إعلان على يد محضر وتكليف بالحضور' },
                  { id: 'whatsapp_update', label: 'صياغة رسالة واتساب للموكل', desc: 'تحديث راقٍ بالقرار وموعد الجلسة' },
                  { id: 'legal_consultation', label: 'استشارة وتأصيل قانوني عام', desc: 'تحليل نصوص القوانين والإجراءات' },
                ].map(item => (
                  <label
                    key={item.id}
                    className={`block p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                      action === item.id
                        ? 'border-amber-500 bg-amber-50/60 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 font-bold'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="action"
                        checked={action === item.id}
                        onChange={() => setAction(item.id)}
                        className="text-amber-600 focus:ring-amber-500"
                      />
                      <span>{item.label}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-normal mr-5 mt-0.5">{item.desc}</p>
                  </label>
                ))}
              </div>
            </div>

            {/* Select Case */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                تطبيق الصياغة على ملف قضية:
              </label>
              <select
                value={selectedCaseId}
                onChange={e => setSelectedCaseId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              >
                <option value="">-- بدون ربط بقضية (مسودة حرة) --</option>
                {cases.map(c => (
                  <option key={c.id} value={c.id}>
                    قضية {c.caseNumber}/{c.year} - {c.clientName} ({c.court})
                  </option>
                ))}
              </select>
            </div>

            {/* Case Info Preview */}
            {selectedCase && (
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
                <div><strong>المحكمة:</strong> {selectedCase.court}</div>
                <div><strong>الموكل:</strong> {selectedCase.clientName} ({selectedCase.clientRole})</div>
                <div><strong>الخصم:</strong> {selectedCase.opponentName}</div>
                <div className="line-clamp-2"><strong>الموضوع:</strong> {selectedCase.subject}</div>
              </div>
            )}

            {/* Additional custom instructions */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                تعليمات ودفوع إضافية ترغب بالتركيز عليها:
              </label>
              <textarea
                rows={3}
                placeholder="مثال: التركيز على الدفع بسقوط الحق بالتقادم، أو إثبات الصلح الموثق، أو طلب بطلان تقرير الخبير..."
                value={customInstructions}
                onChange={e => setCustomInstructions(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full py-2.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 disabled:opacity-50 rounded-xl shadow-md shadow-amber-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>جارٍ الصياغة والتحليل القانوني...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>توليد الصياغة القانونية</span>
                </>
              )}
            </button>

            {errorMsg && (
              <p className="text-xs text-red-500 flex items-center gap-1">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </p>
            )}

          </div>

        </div>

        {/* Right Column: Generated Output Document */}
        <div className="lg:col-span-2">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col min-h-[520px]">
            
            {/* Document Action Toolbar - Hide on print */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 mb-4 no-print">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-600" />
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {generatedText ? 'المحرر القانوني الذكي' : 'معاينة الصياغة'}
                </span>
              </div>

              {generatedText && (
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleCopy}
                    className="px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg flex items-center gap-1 cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'تم النسخ' : 'نسخ النص'}</span>
                  </button>

                  <button
                    onClick={handlePrint}
                    className="px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg flex items-center gap-1 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>طباعة</span>
                  </button>

                  {selectedCase?.clientPhone && (
                    <button
                      onClick={handleSendWhatsApp}
                      className="px-2.5 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>إرسال واتساب</span>
                    </button>
                  )}

                  {onSaveDocToCase && selectedCaseId && (
                    <button
                      onClick={handleSaveToArchive}
                      className="px-2.5 py-1 text-xs font-medium text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      <FolderPlus className="w-3.5 h-3.5" />
                      <span>{isSavedToDocs ? 'تم الحفظ بالأرشيف ✓' : 'حفظ بالأرشيف'}</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Document Content View */}
            {generatedText ? (
              <div className="flex-1 p-4 bg-slate-50/50 dark:bg-slate-950/30 rounded-xl border border-slate-200 dark:border-slate-800 print:bg-white print:border-none print:p-0">
                {/* Print Header */}
                <div className="print-only mb-6 border-b-2 border-slate-800 pb-3">
                  <h2 className="text-base font-bold">{firmProfile.firmName}</h2>
                  <p className="text-xs">{firmProfile.lawyerName} - {firmProfile.title}</p>
                </div>

                <div className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-sans whitespace-pre-wrap selection:bg-amber-200">
                  {generatedText}
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
                <Sparkles className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-3" />
                <h4 className="text-sm font-bold text-slate-600 dark:text-slate-400">
                  المساعد جاهز لتوليد الصياغة القانونية
                </h4>
                <p className="text-xs text-slate-400 max-w-sm mt-1">
                  اختر نوع المهمة (مذكرة دفاع، عريضة دعوى، استخراج دفوع، أو رسالة موكل) واضغط "توليد الصياغة القانونية".
                </p>
              </div>
            )}

          </div>
        </div>

      </div>

    </div>
  );
};
