import React, { useState } from 'react';
import {
  X,
  Calendar,
  FileText,
  DollarSign,
  Sparkles,
  History,
  Clock,
  Plus,
  Share2,
  Printer,
  CheckCircle2,
  AlertCircle,
  FolderOpen,
  Receipt,
  User,
  Scale,
  MessageSquare,
  Building2,
} from 'lucide-react';
import {
  CaseItem,
  CourtSession,
  CaseDocument,
  PaymentRecord,
  ExpenseRecord,
  LawFirmProfile,
} from '../types/legal';
import { formatDateArabic, formatCurrency, createWhatsAppUrl } from '../utils/storage';

interface CaseDetailsModalProps {
  caseItem: CaseItem;
  sessions: CourtSession[];
  documents: CaseDocument[];
  payments: PaymentRecord[];
  expenses: ExpenseRecord[];
  firmProfile: LawFirmProfile;
  isOpen: boolean;
  onClose: () => void;
  onOpenPostponeModal: (session: CourtSession) => void;
  onOpenNewSession: (caseId: string) => void;
  onOpenNewDocument: (caseId: string) => void;
  onOpenNewPayment: (caseId: string) => void;
  onOpenNewExpense: (caseId: string) => void;
  onPrintReceipt: (payment: PaymentRecord, caseItem: CaseItem) => void;
  onOpenAiDraft: (caseItem: CaseItem, initialAction: string) => void;
  onUpdateCaseStatus: (caseId: string, newStatus: CaseItem['status']) => void;
}

type TabType = 'sessions' | 'documents' | 'financials' | 'ai' | 'info';

export const CaseDetailsModal: React.FC<CaseDetailsModalProps> = ({
  caseItem,
  sessions,
  documents,
  payments,
  expenses,
  firmProfile,
  isOpen,
  onClose,
  onOpenPostponeModal,
  onOpenNewSession,
  onOpenNewDocument,
  onOpenNewPayment,
  onOpenNewExpense,
  onPrintReceipt,
  onOpenAiDraft,
  onUpdateCaseStatus,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<TabType>('sessions');

  // Case sessions sorted by date
  const caseSessions = [...sessions].sort(
    (a, b) => new Date(b.sessionDate).getTime() - new Date(a.sessionDate).getTime()
  );

  // Financial calculations
  const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const remainingFee = Math.max(0, caseItem.totalFee - totalPaid);
  const paymentPercentage =
    caseItem.totalFee > 0 ? Math.min(100, Math.round((totalPaid / caseItem.totalFee) * 100)) : 0;

  // Next upcoming session
  const todayStr = new Date().toISOString().split('T')[0];
  const upcomingSession = [...sessions]
    .filter(s => s.sessionDate >= todayStr)
    .sort((a, b) => new Date(a.sessionDate).getTime() - new Date(b.sessionDate).getTime())[0];

  const handlePrintCaseSummary = () => {
    window.print();
  };

  const handleSendWhatsAppUpdate = () => {
    if (!caseItem.clientPhone) return;
    const nextSessionText = upcomingSession
      ? `الجلسة القادمة محددة بتاريخ: ${formatDateArabic(upcomingSession.sessionDate)} (${upcomingSession.decisionOrReason})`
      : 'لا توجد جلسات محددة حالياً';

    const text = `السلام عليكم ورحمة الله وبركاته،
أستاذ/ة ${caseItem.clientName}،
تحية طيبة من ${firmProfile.firmName} (${firmProfile.lawyerName})،
نحيطكم علماً بملخص موقف قضيتكم رقم (${caseItem.caseNumber} لسنة ${caseItem.year}) بمحكمة (${caseItem.court}):
- ${nextSessionText}
- إجمالي الأتعاب المتفق عليها: ${formatCurrency(caseItem.totalFee)}
- المسدد: ${formatCurrency(totalPaid)} | المتبقي: ${formatCurrency(remainingFee)}
لأي استفسار يسعدنا تواصلكم دائماً.`;

    window.open(createWhatsAppUrl(caseItem.clientPhone, text), '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl my-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-4 sm:p-6 text-right max-h-[92vh] flex flex-col">
        
        {/* Top Header */}
        <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4 mb-4 shrink-0">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="text-xl font-extrabold text-slate-900 dark:text-white">
                قضية رقم {caseItem.caseNumber} لسنة {caseItem.year}
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-400">
                {caseItem.caseType}
              </span>
              <span
                className={`text-xs px-2.5 py-0.5 rounded-full font-bold ${
                  caseItem.status === 'جارية'
                    ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/50 dark:text-blue-400'
                    : caseItem.status === 'صلح' || caseItem.status === 'محكومة'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-400'
                    : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}
              >
                {caseItem.status}
              </span>
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap gap-x-4 gap-y-1">
              <span>المحكمة: <strong className="text-slate-700 dark:text-slate-300">{caseItem.court}</strong></span>
              {caseItem.circuit && <span>الدائرة: <strong className="text-slate-700 dark:text-slate-300">{caseItem.circuit}</strong></span>}
              <span>الموكل: <strong className="text-slate-700 dark:text-slate-300">{caseItem.clientName}</strong> ({caseItem.clientRole})</span>
              <span>الخصم: <strong className="text-slate-700 dark:text-slate-300">{caseItem.opponentName}</strong></span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSendWhatsAppUpdate}
              title="مشاركة تحديث القضية عبر واتساب"
              className="p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors cursor-pointer"
            >
              <MessageSquare className="w-5 h-5" />
            </button>
            <button
              onClick={handlePrintCaseSummary}
              title="طباعة ملف القضية"
              className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 mb-4 overflow-x-auto shrink-0 pb-1">
          <button
            onClick={() => setActiveTab('sessions')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'sessions'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>الجلسات والتأجيلات ({caseSessions.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('documents')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'documents'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <FolderOpen className="w-4 h-4" />
            <span>المستندات والأرشيف ({documents.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('financials')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'financials'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>الأتعاب والمصاريف</span>
          </button>

          <button
            onClick={() => setActiveTab('ai')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'ai'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>المساعد الذكي (AI)</span>
          </button>

          <button
            onClick={() => setActiveTab('info')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'info'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>موضوع الدعوى والبيانات</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="overflow-y-auto flex-1 pr-1 pl-1 space-y-4">
          
          {/* TAB 1: SESSIONS & POSTPONEMENTS */}
          {activeTab === 'sessions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    جدول جلسات الدعوى وسجل التأجيلات
                  </h4>
                  <p className="text-xs text-slate-500">
                    متابعة القرارات الإجرائية وتوثيق أسباب التأجيل
                  </p>
                </div>
                <button
                  onClick={() => onOpenNewSession(caseItem.id)}
                  className="px-3 py-1.5 text-xs font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 rounded-lg border border-amber-200 dark:border-amber-800/50 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة جلسة جديدة</span>
                </button>
              </div>

              {caseSessions.length === 0 ? (
                <div className="p-8 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl">
                  <Calendar className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-500">لم يتم تسجيل جلسات لهذه القضية بعد</p>
                  <button
                    onClick={() => onOpenNewSession(caseItem.id)}
                    className="mt-3 text-xs font-bold text-amber-600 hover:underline"
                  >
                    + إضافة أول جلسة
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {caseSessions.map((session, idx) => {
                    const isUpcoming = session.sessionDate >= todayStr;
                    return (
                      <div
                        key={session.id || idx}
                        className={`p-4 rounded-xl border transition-all ${
                          isUpcoming
                            ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/60 shadow-xs'
                            : 'bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700/60'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                              جلسة: {formatDateArabic(session.sessionDate)}
                            </span>
                            {session.courtroom && (
                              <span className="text-xs text-slate-500 dark:text-slate-400">
                                ({session.courtroom})
                              </span>
                            )}
                            {session.rollNumber && (
                              <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                رول #{session.rollNumber}
                              </span>
                            )}
                            {isUpcoming && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-600 text-white">
                                قادمة
                              </span>
                            )}
                          </div>

                          {/* Postpone button */}
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => onOpenPostponeModal(session)}
                              className="px-3 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer"
                            >
                              <History className="w-3.5 h-3.5" />
                              <span>تأجيل الجلسة</span>
                            </button>
                          </div>
                        </div>

                        {/* Decision / Reason */}
                        <div className="text-xs text-slate-800 dark:text-slate-200 mb-2">
                          <strong className="text-slate-600 dark:text-slate-400">القرار أو السبب: </strong>
                          <span className="font-medium text-amber-900 dark:text-amber-300">
                            {session.decisionOrReason}
                          </span>
                        </div>

                        {/* Lawyer notes */}
                        {session.lawyerNotes && (
                          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 mb-2">
                            <span className="font-semibold text-slate-700 dark:text-slate-200">
                              تعليمات للمحامي:
                            </span>{' '}
                            {session.lawyerNotes}
                          </div>
                        )}

                        {/* Postponement History Trail */}
                        {session.postponementHistory && session.postponementHistory.length > 0 && (
                          <div className="mt-3 pt-2.5 border-t border-slate-200/80 dark:border-slate-700/80">
                            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1 mb-1.5">
                              <History className="w-3.5 h-3.5" />
                              <span>سجل التأجيلات لهذه الجلسة:</span>
                            </span>
                            <div className="space-y-1">
                              {session.postponementHistory.map((post, pIdx) => (
                                <div
                                  key={post.id || pIdx}
                                  className="text-[11px] text-slate-600 dark:text-slate-400 flex flex-wrap items-center justify-between p-1.5 rounded bg-slate-100/70 dark:bg-slate-900/40"
                                >
                                  <span>
                                    تأجلت من {formatDateArabic(post.fromDate)} إلى {formatDateArabic(post.toDate)}
                                  </span>
                                  <span className="font-medium text-amber-700 dark:text-amber-400">
                                    السبب: {post.reason}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DOCUMENTS & ELECTRONIC ARCHIVE */}
          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    الأرشيف والمستندات الخاصة بالقضية
                  </h4>
                  <p className="text-xs text-slate-500">
                    توكيلات رسمية، عرائض الدعاوى، مذكرات الدفاع، وتقارير الخبراء
                  </p>
                </div>
                <button
                  onClick={() => onOpenNewDocument(caseItem.id)}
                  className="px-3 py-1.5 text-xs font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 rounded-lg border border-amber-200 dark:border-amber-800/50 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>رفع مستند / مسح ضوئي</span>
                </button>
              </div>

              {documents.length === 0 ? (
                <div className="p-8 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl">
                  <FolderOpen className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-500">لا توجد مستندات مرفوعة لهذه القضية حتى الآن</p>
                  <button
                    onClick={() => onOpenNewDocument(caseItem.id)}
                    className="mt-3 text-xs font-bold text-amber-600 hover:underline"
                  >
                    + رفع أول مستند الآن
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {documents.map((doc, idx) => (
                    <div
                      key={doc.id || idx}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-1.5">
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white line-clamp-1">
                            {doc.title}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-400 shrink-0">
                            {doc.docType}
                          </span>
                        </div>
                        {doc.powerOfAttorneyNumber && (
                          <p className="text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                            رقم التوكيل: <strong>{doc.powerOfAttorneyNumber}</strong> ({doc.notaryOffice})
                          </p>
                        )}
                        {doc.notes && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-2">
                            {doc.notes}
                          </p>
                        )}
                      </div>

                      <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
                        <span>{doc.fileName || 'ملف مرفق'} {doc.fileSize && `· ${doc.fileSize}`}</span>
                        <span className="text-amber-600 font-medium">مؤرشف محلياً</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: FINANCIALS & EXPENSES */}
          {activeTab === 'financials' && (
            <div className="space-y-5">
              
              {/* Financial KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">إجمالي الأتعاب</span>
                  <div className="text-base font-extrabold text-slate-900 dark:text-white mt-1 tabular-nums">
                    {formatCurrency(caseItem.totalFee)}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/40">
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-400">المحصل من الأتعاب</span>
                  <div className="text-base font-extrabold text-emerald-800 dark:text-emerald-300 mt-1 tabular-nums">
                    {formatCurrency(totalPaid)}
                  </div>
                  <div className="text-[10px] text-emerald-600 mt-0.5">
                    نسبة السداد: {paymentPercentage}%
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-amber-50/50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40">
                  <span className="text-[11px] text-amber-700 dark:text-amber-400">المتبقي طرف الموكل</span>
                  <div className="text-base font-extrabold text-amber-800 dark:text-amber-300 mt-1 tabular-nums">
                    {formatCurrency(remainingFee)}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">مصاريف القضية (رسوم/دمغات)</span>
                  <div className="text-base font-extrabold text-slate-900 dark:text-white mt-1 tabular-nums">
                    {formatCurrency(totalExpenses)}
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span>سداد الأتعاب</span>
                  <span className="tabular-nums">{paymentPercentage}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                    style={{ width: `${paymentPercentage}%` }}
                  />
                </div>
              </div>

              {/* Payments Section */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Receipt className="w-4 h-4 text-emerald-600" />
                    <span>سجل المقبوضات والدفعات ({payments.length})</span>
                  </h5>
                  <button
                    onClick={() => onOpenNewPayment(caseItem.id)}
                    className="px-2.5 py-1 text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 rounded-lg border border-emerald-200 dark:border-emerald-800/50 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>تسجيل دفعة أتعاب</span>
                  </button>
                </div>

                {payments.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">لم يتم تسجيل أي دفعات أتعاب حتى الآن</p>
                ) : (
                  <div className="space-y-2">
                    {payments.map(p => (
                      <div
                        key={p.id}
                        className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/40 flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-extrabold text-sm text-slate-900 dark:text-white tabular-nums">
                              {formatCurrency(p.amount)}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                              {p.paymentMethod}
                            </span>
                            <span className="text-xs text-slate-500 font-mono">
                              #{p.receiptNumber}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            التاريخ: {formatDateArabic(p.date)} {p.notes && `· ${p.notes}`}
                          </p>
                        </div>
                        <button
                          onClick={() => onPrintReceipt(p, caseItem)}
                          className="px-2.5 py-1 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg border border-slate-300 dark:border-slate-700 flex items-center gap-1 cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>طباعة سند قبض</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Expenses Section */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <h5 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <DollarSign className="w-4 h-4 text-amber-600" />
                    <span>سجل مصاريف القضية والرسوم ({expenses.length})</span>
                  </h5>
                  <button
                    onClick={() => onOpenNewExpense(caseItem.id)}
                    className="px-2.5 py-1 text-xs font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 rounded-lg border border-amber-200 dark:border-amber-800/50 flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>تسجيل مصروف</span>
                  </button>
                </div>

                {expenses.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">لا توجد مصاريف مسجلة</p>
                ) : (
                  <div className="space-y-1.5">
                    {expenses.map(e => (
                      <div
                        key={e.id}
                        className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between"
                      >
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200">{e.title}</span>
                          <span className="text-[11px] text-slate-400 mr-2">({e.category})</span>
                          <span className="text-[11px] text-slate-400 mr-2">· {e.date}</span>
                        </div>
                        <span className="font-bold text-slate-900 dark:text-white tabular-nums">
                          {formatCurrency(e.amount)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 4: AI LEGAL ASSISTANT SHORTCUTS */}
          {activeTab === 'ai' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent border border-amber-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-5 h-5 text-amber-600" />
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    المساعد الذكي لهذه القضية
                  </h4>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mb-4">
                  استخدم محرك الذكاء الاصطناعي القانوني لصياغة مذكرات الدفاع، تحليل الدفوع، أو إعداد رسائل الموكلين التلقائية.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    onClick={() => onOpenAiDraft(caseItem, 'draft_memo')}
                    className="p-3 text-right rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-amber-500 transition-colors shadow-xs group cursor-pointer"
                  >
                    <div className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-amber-600">
                      صياغة مذكرة دفاع كاملة
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      توليد ديباجة رسمية، وقائع، دفوع قانونية، وطلبات ختامية
                    </div>
                  </button>

                  <button
                    onClick={() => onOpenAiDraft(caseItem, 'suggest_defenses')}
                    className="p-3 text-right rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-amber-500 transition-colors shadow-xs group cursor-pointer"
                  >
                    <div className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-amber-600">
                      اقتراح الدفوع الشكلية والموضوعية
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      تحديد الثغرات ونقاط القوة في موقف الموكل والدفوع المناسبة
                    </div>
                  </button>

                  <button
                    onClick={() => onOpenAiDraft(caseItem, 'whatsapp_update')}
                    className="p-3 text-right rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-amber-500 transition-colors shadow-xs group cursor-pointer"
                  >
                    <div className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-amber-600">
                      صياغة رسالة واتساب للموكل
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      رسالة طمأنة وتوضيح لموعد الجلسة والقرار بلغة راقية
                    </div>
                  </button>

                  <button
                    onClick={() => onOpenAiDraft(caseItem, 'draft_lawsuit')}
                    className="p-3 text-right rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-amber-500 transition-colors shadow-xs group cursor-pointer"
                  >
                    <div className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-amber-600">
                      صياغة عريضة دعوى / إنذار رسمي
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      توليد صيغة إعلان على يد محضر وفقاً لقانون المرافعات
                    </div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: CASE DETAILS & STATUS UPDATE */}
          {activeTab === 'info' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-2">
                  <h5 className="text-xs font-bold text-amber-700 dark:text-amber-400">بيانات الخصومة</h5>
                  <div className="text-xs space-y-1">
                    <p><strong>الموكل:</strong> {caseItem.clientName} ({caseItem.clientRole})</p>
                    <p><strong>هاتف الموكل:</strong> {caseItem.clientPhone}</p>
                    {caseItem.clientEmail && <p><strong>البريد:</strong> {caseItem.clientEmail}</p>}
                    {caseItem.clientAddress && <p><strong>العنوان:</strong> {caseItem.clientAddress}</p>}
                    <hr className="border-slate-200 dark:border-slate-700 my-1" />
                    <p><strong>الخصم:</strong> {caseItem.opponentName}</p>
                    {caseItem.opponentLawyer && <p><strong>محامي الخصم:</strong> {caseItem.opponentLawyer}</p>}
                    {caseItem.opponentPhone && <p><strong>هاتف الخصم:</strong> {caseItem.opponentPhone}</p>}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 space-y-2">
                  <h5 className="text-xs font-bold text-amber-700 dark:text-amber-400">حالة القضية والتواريخ</h5>
                  <div className="text-xs space-y-2">
                    <div>
                      <label className="block text-[11px] text-slate-500 mb-1">تعديل حالة القضية:</label>
                      <select
                        value={caseItem.status}
                        onChange={e => onUpdateCaseStatus(caseItem.id, e.target.value as CaseItem['status'])}
                        className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg"
                      >
                        <option value="جارية">جارية</option>
                        <option value="مؤجلة">مؤجلة</option>
                        <option value="محكومة">محكومة (صدر حكم)</option>
                        <option value="صلح">صلح وانقضاء</option>
                        <option value="مشطوبة">مشطوبة</option>
                        <option value="محفوظة">محفوظة بالأرشيف</option>
                      </select>
                    </div>
                    <p className="text-slate-400 text-[11px]">
                      تاريخ القيد: {caseItem.createdAt} · آخر تحديث: {caseItem.updatedAt}
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
                <h5 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  موضوع الدعوى
                </h5>
                <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {caseItem.subject}
                </p>
                {caseItem.notes && (
                  <>
                    <h5 className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-3 mb-1">
                      ملاحظات إضافية
                    </h5>
                    <p className="text-xs text-slate-600 dark:text-slate-400 whitespace-pre-wrap">
                      {caseItem.notes}
                    </p>
                  </>
                )}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
