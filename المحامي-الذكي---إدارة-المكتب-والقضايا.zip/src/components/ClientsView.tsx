import React, { useState } from 'react';
import {
  Users,
  Search,
  Phone,
  MessageSquare,
  Calendar,
  Clock,
  Plus,
  Briefcase,
  AlertTriangle,
  CheckCircle,
  FileText,
  DollarSign,
  ChevronLeft,
  Printer,
} from 'lucide-react';
import { ClientItem, ConsultationItem, CaseItem, CourtSession } from '../types/legal';
import { formatCurrency, formatDateArabic, createWhatsAppUrl } from '../utils/storage';

interface ClientsViewProps {
  clients: ClientItem[];
  cases: CaseItem[];
  consultations: ConsultationItem[];
  sessions: CourtSession[];
  onOpenNewConsultation: () => void;
  onOpenNewClient: (client: ClientItem) => void;
  onSelectCase: (caseItem: CaseItem) => void;
}

export const ClientsView: React.FC<ClientsViewProps> = ({
  clients,
  cases,
  consultations,
  sessions,
  onOpenNewConsultation,
  onOpenNewClient,
  onSelectCase,
}) => {
  const [subTab, setSubTab] = useState<'clients' | 'consultations'>('clients');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewClientForm, setShowNewClientForm] = useState(false);

  // New client form states
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newNationalId, setNewNationalId] = useState('');
  const [newAddress, setNewAddress] = useState('');
  const [newNotes, setNewNotes] = useState('');

  const todayStr = new Date().toISOString().split('T')[0];

  // Helper to find all cases for a client
  const getClientCases = (clientName: string, clientPhone: string) => {
    return cases.filter(
      c =>
        c.clientName.trim().toLowerCase() === clientName.trim().toLowerCase() ||
        (clientPhone && c.clientPhone.replace(/[^0-9]/g, '') === clientPhone.replace(/[^0-9]/g, ''))
    );
  };

  // Filter clients
  const filteredClients = clients.filter(
    c =>
      searchQuery === '' ||
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      (c.nationalId && c.nationalId.includes(searchQuery)) ||
      (c.notes && c.notes.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleCreateClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) return;

    const newClient: ClientItem = {
      id: 'client-' + Date.now(),
      name: newName.trim(),
      phone: newPhone.trim(),
      email: newEmail.trim() || undefined,
      nationalId: newNationalId.trim() || undefined,
      address: newAddress.trim() || undefined,
      notes: newNotes.trim() || undefined,
      createdAt: todayStr,
    };

    onOpenNewClient(newClient);
    setNewName('');
    setNewPhone('');
    setNewEmail('');
    setNewNationalId('');
    setNewAddress('');
    setNewNotes('');
    setShowNewClientForm(false);
  };

  return (
    <div className="space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-600" />
            <span>دليل الموكلين ومواعيد الاستشارات</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            أرشيف بيانات الموكلين وقضاياهم السابقة والحالية، وجدول مقابلات المكتب
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-600" />
            <span>طباعة {subTab === 'clients' ? 'دليل الموكلين' : 'جدول الاستشارات'}</span>
          </button>

          {subTab === 'clients' ? (
            <button
              onClick={() => setShowNewClientForm(true)}
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة موكل جديد</span>
            </button>
          ) : (
            <button
              onClick={onOpenNewConsultation}
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>حجز موعد استشارة</span>
            </button>
          )}
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="p-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl flex gap-1 w-fit">
        <button
          onClick={() => setSubTab('clients')}
          className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            subTab === 'clients'
              ? 'bg-white dark:bg-slate-900 text-amber-700 dark:text-amber-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          دليل الموكلين ({clients.length})
        </button>

        <button
          onClick={() => setSubTab('consultations')}
          className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
            subTab === 'consultations'
              ? 'bg-white dark:bg-slate-900 text-amber-700 dark:text-amber-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          مواعيد المقابلات والاستشارات ({consultations.length})
        </button>
      </div>

      {/* SUBTAB 1: CLIENTS DIRECTORY */}
      {subTab === 'clients' && (
        <div className="space-y-4">
          
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 pointer-events-none" />
            <input
              type="text"
              placeholder="ابحث باسم الموكل، رقم الهاتف، أو الرقم القومي..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-amber-500 dark:text-white"
            />
          </div>

          {/* New Client Modal/Card */}
          {showNewClientForm && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border-2 border-amber-500/50 shadow-lg text-right">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
                تسجيل موكل جديد في الدليل
              </h3>
              <form onSubmit={handleCreateClient} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold mb-1">اسم الموكل *</label>
                    <input
                      type="text"
                      required
                      placeholder="الاسم الثلاثي أو الرباعي"
                      value={newName}
                      onChange={e => setNewName(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold mb-1">رقم الهاتف (الواتساب) *</label>
                    <input
                      type="tel"
                      required
                      placeholder="01xxxxxxxxx"
                      value={newPhone}
                      onChange={e => setNewPhone(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold mb-1">الرقم القومي / الهوية</label>
                    <input
                      type="text"
                      placeholder="14 رقماً"
                      value={newNationalId}
                      onChange={e => setNewNationalId(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold mb-1">البريد الإلكتروني</label>
                    <input
                      type="email"
                      value={newEmail}
                      onChange={e => setNewEmail(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold mb-1">العنوان أو مكان الإقامة</label>
                    <input
                      type="text"
                      value={newAddress}
                      onChange={e => setNewAddress(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold mb-1">ملاحظات عن الموكل</label>
                  <input
                    type="text"
                    placeholder="طريقة التواصل المفضلة أو طبيعة النزاعات..."
                    value={newNotes}
                    onChange={e => setNewNotes(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowNewClientForm(false)}
                    className="px-3 py-1.5 text-xs text-slate-500 hover:bg-slate-100 rounded-lg"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
                  >
                    حفظ الموكل
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Clients Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredClients.map(client => {
              const clientCases = getClientCases(client.name, client.phone);
              const totalFees = clientCases.reduce((sum, c) => sum + (c.totalFee || 0), 0);

              return (
                <div
                  key={client.id}
                  className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                          {client.name}
                        </h3>
                        {client.companyName && (
                          <span className="text-xs text-amber-700 dark:text-amber-400 font-semibold">
                            {client.companyName}
                          </span>
                        )}
                      </div>

                      {/* Direct phone and whatsapp buttons */}
                      <div className="flex items-center gap-1.5">
                        <a
                          href={`tel:${client.phone}`}
                          title="اتصال هاتفي"
                          className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                        >
                          <Phone className="w-4 h-4" />
                        </a>
                        <a
                          href={createWhatsAppUrl(client.phone, `مرحباً أستاذ/ة ${client.name}، بخصوص ملفكم بمكتبنا:`)}
                          target="_blank"
                          rel="noreferrer"
                          title="محادثة واتساب مباشرة"
                          className="p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg border border-emerald-200 dark:border-emerald-800"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </a>
                      </div>
                    </div>

                    <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1 mb-3">
                      <div>هاتف: <span className="font-mono font-bold text-slate-700 dark:text-slate-200">{client.phone}</span></div>
                      {client.nationalId && <div>الرقم القومي: <span className="font-mono">{client.nationalId}</span></div>}
                      {client.address && <div>العنوان: {client.address}</div>}
                    </div>

                    {/* Associated Cases */}
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                      <span className="text-[11px] font-bold text-slate-400 block mb-1.5">
                        القضايا المسجلة لهذا الموكل ({clientCases.length}):
                      </span>

                      {clientCases.length === 0 ? (
                        <p className="text-[11px] text-slate-400 italic">لا توجد قضايا مقيدة حالياً</p>
                      ) : (
                        <div className="space-y-1.5">
                          {clientCases.map(c => (
                            <div
                              key={c.id}
                              onClick={() => onSelectCase(c)}
                              className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 hover:bg-amber-50 dark:hover:bg-amber-950/30 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs cursor-pointer transition-colors"
                            >
                              <div className="truncate">
                                <span className="font-bold text-slate-800 dark:text-slate-200">
                                  قضية {c.caseNumber}/{c.year}
                                </span>{' '}
                                <span className="text-slate-500">({c.caseType} - {c.court})</span>
                              </div>
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 shrink-0">
                                {c.status}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400 mt-3">
                    <span>إجمالي الأتعاب المتعاقد عليها:</span>
                    <span className="font-bold text-slate-900 dark:text-white tabular-nums">
                      {formatCurrency(totalFees)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* SUBTAB 2: CONSULTATIONS & APPOINTMENTS */}
      {subTab === 'consultations' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                جدول مقابلات الموكلين واستشارات المكتب
              </h3>
              <p className="text-xs text-slate-500">
                تنظيم جدول المواعيد لتجنب تداخل أوقات الاستشارات مع جلسات المحاكم
              </p>
            </div>
            <button
              onClick={onOpenNewConsultation}
              className="px-3 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>حجز موعد</span>
            </button>
          </div>

          <div className="space-y-3">
            {consultations.length === 0 ? (
              <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400">
                <Calendar className="w-10 h-10 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                <p className="text-xs">لا توجد مواعيد استشارات مسجلة</p>
              </div>
            ) : (
              consultations.map(con => {
                const hasCourtConflict = sessions.some(s => s.sessionDate === con.date);

                return (
                  <div
                    key={con.id}
                    className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-bold text-slate-900 dark:text-white">
                          {con.clientName}
                        </span>
                        <span className="text-xs font-mono font-bold text-purple-700 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 px-2 py-0.5 rounded">
                          {con.time} ({con.durationMinutes} دقيقة)
                        </span>
                        <span className="text-xs text-slate-500">
                          {formatDateArabic(con.date)}
                        </span>
                      </div>

                      <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                        موضوع الاستشارة: {con.topic}
                      </p>

                      {con.notes && (
                        <p className="text-[11px] text-slate-400 italic mt-0.5">{con.notes}</p>
                      )}

                      {hasCourtConflict && (
                        <div className="mt-1.5 flex items-center gap-1 text-[11px] text-amber-700 dark:text-amber-400">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>تنويه: يوجد جلسات محكمة في نفس هذا اليوم</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <div className="text-left text-xs mr-2">
                        <span className="font-bold text-slate-900 dark:text-white block tabular-nums">
                          {formatCurrency(con.fee)}
                        </span>
                        <span className={`text-[10px] ${con.isPaid ? 'text-emerald-600' : 'text-amber-600'}`}>
                          {con.isPaid ? 'مسدد' : 'غير مسدد'}
                        </span>
                      </div>

                      <a
                        href={createWhatsAppUrl(con.phone, `أهلاً بك أستاذ/ة ${con.clientName}، تذكير بموعد استشارتكم القانونية بمكتبنا بتاريخ ${con.date} في تمام الساعة ${con.time}:`)}
                        target="_blank"
                        rel="noreferrer"
                        title="إرسال تذكير واتساب"
                        className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg border border-emerald-200 dark:border-emerald-800"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

    </div>
  );
};
