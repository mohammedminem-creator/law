import React, { useState } from 'react';
import {
  DollarSign,
  Receipt,
  Plus,
  Printer,
  Calendar,
  Briefcase,
  TrendingUp,
  CreditCard,
  Building2,
  FileText,
  Search,
} from 'lucide-react';
import { PaymentRecord, ExpenseRecord, CaseItem, LawFirmProfile } from '../types/legal';
import { formatCurrency, formatDateArabic } from '../utils/storage';

interface FinancialsViewProps {
  cases: CaseItem[];
  payments: PaymentRecord[];
  expenses: ExpenseRecord[];
  firmProfile: LawFirmProfile;
  onOpenNewPayment: (caseId?: string) => void;
  onOpenNewExpense: (caseId?: string) => void;
  onPrintReceipt: (payment: PaymentRecord, caseItem: CaseItem) => void;
  onSelectCase: (caseItem: CaseItem) => void;
}

export const FinancialsView: React.FC<FinancialsViewProps> = ({
  cases,
  payments,
  expenses,
  firmProfile,
  onOpenNewPayment,
  onOpenNewExpense,
  onPrintReceipt,
  onSelectCase,
}) => {
  const [activeTab, setActiveTab] = useState<'payments' | 'expenses' | 'summary'>('payments');
  const [selectedCaseId, setSelectedCaseId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const getCase = (caseId: string) => cases.find(c => c.id === caseId);

  // Financial aggregates
  const totalAgreed = cases.reduce((acc, c) => acc + (c.totalFee || 0), 0);
  const totalCollected = payments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const totalRemaining = Math.max(0, totalAgreed - totalCollected);
  const totalExpenses = expenses.reduce((acc, e) => acc + (e.amount || 0), 0);
  const netOfficeIncome = totalCollected - totalExpenses;

  // Filtered payments
  const filteredPayments = payments.filter(p => {
    const matchCase = selectedCaseId === 'all' || p.caseId === selectedCaseId;
    const c = getCase(p.caseId);
    const matchSearch =
      searchQuery === '' ||
      p.receiptNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c && c.clientName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (p.notes && p.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCase && matchSearch;
  });

  // Filtered expenses
  const filteredExpenses = expenses.filter(e => {
    const matchCase = selectedCaseId === 'all' || e.caseId === selectedCaseId;
    const c = getCase(e.caseId);
    const matchSearch =
      searchQuery === '' ||
      e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c && c.clientName.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchCase && matchSearch;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-600" />
            <span>المساعد المالي وحساب الأتعاب والمصاريف</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            متابعة دفعات الموكلين، إصدار سندات القبض، وتسجيل الرسوم والدمغات القضائية
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-emerald-600" />
            <span>طباعة كشف الحساب</span>
          </button>

          <button
            onClick={() => onOpenNewPayment()}
            className="px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 rounded-xl shadow-sm flex items-center gap-1.5 cursor-pointer"
          >
            <Receipt className="w-4 h-4" />
            <span>سند قبض أتعاب</span>
          </button>

          <button
            onClick={() => onOpenNewExpense()}
            className="px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-amber-600" />
            <span>تسجيل مصروف</span>
          </button>
        </div>
      </div>

      {/* Financial KPI Dashboard Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">إجمالي الأتعاب التعاقدية</span>
          <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1 tabular-nums">
            {formatCurrency(totalAgreed)}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">لكافة القضايا المقيدة</span>
        </div>

        <div className="p-4 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 shadow-xs">
          <span className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">المحصل الفعلي (المقبوض)</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-700 dark:text-emerald-400 mt-1 tabular-nums">
            {formatCurrency(totalCollected)}
          </div>
          <span className="text-[11px] text-emerald-600 dark:text-emerald-500 block mt-1">
            نسبة التحصيل العامة: {totalAgreed > 0 ? Math.round((totalCollected / totalAgreed) * 100) : 0}%
          </span>
        </div>

        <div className="p-4 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 shadow-xs">
          <span className="text-xs font-semibold text-amber-800 dark:text-amber-300">المتبقي لدى الموكلين</span>
          <div className="text-xl sm:text-2xl font-black text-amber-700 dark:text-amber-400 mt-1 tabular-nums">
            {formatCurrency(totalRemaining)}
          </div>
          <span className="text-[11px] text-amber-600 dark:text-amber-500 block mt-1">مستحقات واجبة المتابعة</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 shadow-xs">
          <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">مصاريف القضايا والرسوم</span>
          <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1 tabular-nums">
            {formatCurrency(totalExpenses)}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">رسوم، دمغات، خبراء، إعلانات</span>
        </div>

      </div>

      {/* Tabs & Filter Bar */}
      <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
        
        {/* Tab buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab('payments')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'payments'
                ? 'bg-emerald-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            سجل مقبوضات الأتعاب ({filteredPayments.length})
          </button>

          <button
            onClick={() => setActiveTab('expenses')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'expenses'
                ? 'bg-amber-600 text-white'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            سجل مصاريف القضايا ({filteredExpenses.length})
          </button>

          <button
            onClick={() => setActiveTab('summary')}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'summary'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            كشف حساب القضايا
          </button>
        </div>

        {/* Case filter */}
        <div className="flex items-center gap-2">
          <select
            value={selectedCaseId}
            onChange={e => setSelectedCaseId(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg dark:text-white"
          >
            <option value="all">كافة القضايا</option>
            {cases.map(c => (
              <option key={c.id} value={c.id}>
                قضية {c.caseNumber}/{c.year} - {c.clientName}
              </option>
            ))}
          </select>
        </div>

      </div>

      {/* Tab 1: Payments List */}
      {activeTab === 'payments' && (
        <div className="space-y-3">
          {filteredPayments.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400">
              <Receipt className="w-10 h-10 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
              <p className="text-xs">لا توجد دفعات أتعاب مسجلة</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredPayments.map(payment => {
                const caseItem = getCase(payment.caseId);
                const casePayments = payments.filter(p => p.caseId === payment.caseId);
                const totalPaidForCase = casePayments.reduce((s, p) => s + p.amount, 0);

                return (
                  <div
                    key={payment.id}
                    className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 transition-all shadow-xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <span className="text-base font-black text-emerald-700 dark:text-emerald-400 tabular-nums">
                            {formatCurrency(payment.amount)}
                          </span>
                          <span className="text-xs text-slate-400 mr-2 font-mono">
                            {payment.receiptNumber}
                          </span>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {payment.paymentMethod}
                        </span>
                      </div>

                      {caseItem && (
                        <div className="text-xs text-slate-700 dark:text-slate-300 mb-1">
                          <strong className="text-slate-500">الموكل:</strong> {caseItem.clientName}
                          <div className="text-slate-500">
                            قضية {caseItem.caseNumber}/{caseItem.year} ({caseItem.court})
                          </div>
                        </div>
                      )}

                      <div className="text-[11px] text-slate-400 mt-1">
                        تاريخ السداد: {formatDateArabic(payment.date)}
                        {payment.notes && ` · ${payment.notes}`}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs mt-3">
                      <span className="text-[11px] text-slate-400">
                        مستلم بواسطة: {payment.receivedBy}
                      </span>

                      {caseItem && (
                        <button
                          onClick={() => onPrintReceipt(payment, caseItem)}
                          className="px-3 py-1 text-xs font-bold text-slate-800 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-lg flex items-center gap-1 cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5 text-emerald-600" />
                          <span>طباعة السند</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Expenses List */}
      {activeTab === 'expenses' && (
        <div className="space-y-3">
          {filteredExpenses.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400">
              <DollarSign className="w-10 h-10 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
              <p className="text-xs">لا توجد مصاريف قضائية مسجلة</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredExpenses.map(exp => {
                const caseItem = getCase(exp.caseId);
                return (
                  <div
                    key={exp.id}
                    className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 dark:text-white">
                          {exp.title}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-400">
                          {exp.category}
                        </span>
                      </div>
                      {caseItem && (
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          قضية {caseItem.caseNumber}/{caseItem.year} - {caseItem.clientName} ({caseItem.court})
                        </div>
                      )}
                      {exp.notes && (
                        <p className="text-[11px] text-slate-400 italic mt-0.5">{exp.notes}</p>
                      )}
                    </div>

                    <div className="text-left shrink-0">
                      <span className="font-black text-sm text-slate-900 dark:text-white tabular-nums">
                        {formatCurrency(exp.amount)}
                      </span>
                      <span className="text-[10px] text-slate-400 block">{exp.date}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Case Ledger Summary */}
      {activeTab === 'summary' && (
        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 pb-2">
                <th className="py-2">القضية</th>
                <th className="py-2">الموكل</th>
                <th className="py-2">الأتعاب المتفق عليها</th>
                <th className="py-2">المسدد</th>
                <th className="py-2">المتبقي</th>
                <th className="py-2">المصاريف</th>
                <th className="py-2 text-left">الإجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {cases.map(c => {
                const casePayments = payments.filter(p => p.caseId === c.id);
                const paid = casePayments.reduce((s, p) => s + p.amount, 0);
                const rem = Math.max(0, c.totalFee - paid);
                const caseExpenses = expenses.filter(e => e.caseId === c.id);
                const expTotal = caseExpenses.reduce((s, e) => s + e.amount, 0);

                return (
                  <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-3 font-bold text-slate-900 dark:text-white">
                      قضية {c.caseNumber}/{c.year} ({c.caseType})
                    </td>
                    <td className="py-3 text-slate-700 dark:text-slate-300">
                      {c.clientName}
                    </td>
                    <td className="py-3 font-bold tabular-nums">
                      {formatCurrency(c.totalFee)}
                    </td>
                    <td className="py-3 font-bold text-emerald-600 tabular-nums">
                      {formatCurrency(paid)}
                    </td>
                    <td className="py-3 font-bold text-amber-600 tabular-nums">
                      {formatCurrency(rem)}
                    </td>
                    <td className="py-3 text-slate-500 tabular-nums">
                      {formatCurrency(expTotal)}
                    </td>
                    <td className="py-3 text-left">
                      <button
                        onClick={() => onSelectCase(c)}
                        className="px-2.5 py-1 text-[11px] font-bold text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40 rounded-lg cursor-pointer"
                      >
                        عرض التفاصيل
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

    </div>
  );
};
