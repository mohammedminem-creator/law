import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Clock,
  Printer,
  History,
  CheckCircle2,
  AlertCircle,
  Filter,
  Plus,
  Scale,
  Building2,
  User,
  MessageSquare,
} from 'lucide-react';
import { CourtSession, CaseItem, LawFirmProfile } from '../types/legal';
import { formatDateArabic, createWhatsAppUrl } from '../utils/storage';

interface DocketViewProps {
  sessions: CourtSession[];
  cases: CaseItem[];
  firmProfile: LawFirmProfile;
  onOpenPostponeModal: (session: CourtSession) => void;
  onOpenNewSession: () => void;
  onSelectCase: (caseItem: CaseItem) => void;
}

export const DocketView: React.FC<DocketViewProps> = ({
  sessions,
  cases,
  firmProfile,
  onOpenPostponeModal,
  onOpenNewSession,
  onSelectCase,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const [dateFilter, setDateFilter] = useState<'today' | 'tomorrow' | 'week' | 'all' | 'custom'>('today');
  const [customDate, setCustomDate] = useState(todayStr);

  const getCase = (caseId: string) => cases.find(c => c.id === caseId);

  // Filter sessions according to chosen date filter
  const filteredSessions = useMemo(() => {
    let result = [...sessions];

    if (dateFilter === 'today') {
      result = result.filter(s => s.sessionDate === todayStr);
    } else if (dateFilter === 'tomorrow') {
      result = result.filter(s => s.sessionDate === tomorrowStr);
    } else if (dateFilter === 'week') {
      const nextWeek = new Date();
      nextWeek.setDate(nextWeek.getDate() + 7);
      const nextWeekStr = nextWeek.toISOString().split('T')[0];
      result = result.filter(s => s.sessionDate >= todayStr && s.sessionDate <= nextWeekStr);
    } else if (dateFilter === 'custom') {
      result = result.filter(s => s.sessionDate === customDate);
    } else {
      // all upcoming
      result = result.filter(s => s.sessionDate >= todayStr);
    }

    // Sort by date, then roll number
    return result.sort((a, b) => {
      const dateCmp = new Date(a.sessionDate).getTime() - new Date(b.sessionDate).getTime();
      if (dateCmp !== 0) return dateCmp;
      return (a.rollNumber || 999) - (b.rollNumber || 999);
    });
  }, [sessions, dateFilter, customDate, todayStr, tomorrowStr]);

  const handlePrintRoll = () => {
    window.print();
  };

  return (
    <div className="space-y-5">
      
      {/* Header Bar - Hide on print */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-600" />
            <span>رول الجلسات والأجندة القضائية</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            جدول رول المحاكم اليومي ومتابعة التأجيلات داخل قاعات الجلسات
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrintRoll}
            className="px-3.5 py-2 text-xs font-bold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-600" />
            <span>طباعة الرول</span>
          </button>

          <button
            onClick={onOpenNewSession}
            className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-xl shadow-sm shadow-amber-600/20 flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة جلسة</span>
          </button>
        </div>
      </div>

      {/* Date Filter Tabs - Hide on print */}
      <div className="p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-1.5 text-xs no-print">
        <button
          onClick={() => setDateFilter('today')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer ${
            dateFilter === 'today'
              ? 'bg-amber-600 text-white'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          جلسات اليوم ({sessions.filter(s => s.sessionDate === todayStr).length})
        </button>

        <button
          onClick={() => setDateFilter('tomorrow')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer ${
            dateFilter === 'tomorrow'
              ? 'bg-amber-600 text-white'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          جلسات الغد ({sessions.filter(s => s.sessionDate === tomorrowStr).length})
        </button>

        <button
          onClick={() => setDateFilter('week')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer ${
            dateFilter === 'week'
              ? 'bg-amber-600 text-white'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          خلال 7 أيام
        </button>

        <button
          onClick={() => setDateFilter('all')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer ${
            dateFilter === 'all'
              ? 'bg-amber-600 text-white'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          كل الجلسات القادمة
        </button>

        <div className="flex items-center gap-1.5 mr-auto">
          <span className="text-[11px] text-slate-400">تاريخ محدد:</span>
          <input
            type="date"
            value={customDate}
            onChange={e => {
              setCustomDate(e.target.value);
              setDateFilter('custom');
            }}
            className="px-2 py-1 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg dark:text-white"
          />
        </div>
      </div>

      {/* Printable Court Roll Header (Visible in print and top of docket) */}
      <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 print:border-none print:p-0">
        <div className="border-b-2 border-slate-800 dark:border-slate-200 pb-3 mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-black text-slate-900 dark:text-white">
              {firmProfile.firmName} - {firmProfile.lawyerName}
            </h1>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              رول جلسات المحاكم ليوم: <strong className="text-amber-700 dark:text-amber-400">{dateFilter === 'today' ? formatDateArabic(todayStr) : dateFilter === 'tomorrow' ? formatDateArabic(tomorrowStr) : formatDateArabic(customDate)}</strong>
            </p>
          </div>
          <div className="text-left text-xs font-bold text-slate-500">
            عدد الجلسات: {filteredSessions.length}
          </div>
        </div>

        {/* Sessions Table / Cards */}
        {filteredSessions.length === 0 ? (
          <div className="p-12 text-center text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
            <Calendar className="w-10 h-10 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
            <p className="text-xs">لا توجد جلسات مجدولة في هذا التاريخ</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredSessions.map((session, index) => {
              const caseItem = getCase(session.caseId);
              return (
                <div
                  key={session.id}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 print:bg-white print:border-slate-400 print-break-inside-avoid"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    
                    {/* Left: Session Court & Roll Info */}
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex flex-col items-center justify-center shrink-0 font-bold">
                        <span className="text-[10px] leading-tight">رول</span>
                        <span className="text-sm leading-none tabular-nums">
                          {session.rollNumber || index + 1}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          {caseItem && (
                            <span className="text-sm font-extrabold text-slate-900 dark:text-white">
                              قضية {caseItem.caseNumber}/{caseItem.year} ({caseItem.caseType})
                            </span>
                          )}
                          <span className="text-xs font-bold text-amber-700 dark:text-amber-400">
                            {caseItem?.court} {session.courtroom && `(${session.courtroom})`}
                          </span>
                        </div>

                        {caseItem && (
                          <div className="text-xs text-slate-600 dark:text-slate-400 flex flex-wrap gap-x-3">
                            <span><strong>الموكل:</strong> {caseItem.clientName} ({caseItem.clientRole})</span>
                            <span><strong>الخصم:</strong> {caseItem.opponentName} {caseItem.opponentLawyer && `(محاميه: ${caseItem.opponentLawyer})`}</span>
                          </div>
                        )}

                        <div className="text-xs text-slate-800 dark:text-slate-200 pt-1">
                          <strong className="text-slate-500">القرار / سبب الجلسة:</strong>{' '}
                          <span className="font-semibold text-amber-900 dark:text-amber-300">
                            {session.decisionOrReason}
                          </span>
                        </div>

                        {session.lawyerNotes && (
                          <div className="text-[11px] text-slate-500 italic">
                            ملاحظة للمحامي: {session.lawyerNotes}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right: Actions (Postpone, WhatsApp, View Case) - Hide on print */}
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center no-print">
                      <button
                        onClick={() => onOpenPostponeModal(session)}
                        className="px-3 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        <History className="w-3.5 h-3.5" />
                        <span>تأجيل الجلسة</span>
                      </button>

                      {caseItem?.clientPhone && (
                        <a
                          href={createWhatsAppUrl(
                            caseItem.clientPhone,
                            `تحية طيبة أستاذ/ة ${caseItem.clientName}، نحيطكم علماً بأن جلستكم اليوم في القضية (${caseItem.caseNumber}/${caseItem.year}) بمحكمة (${caseItem.court}) تسير وفق المخطط:`
                          )}
                          target="_blank"
                          rel="noreferrer"
                          title="إرسال رسالة للموكل"
                          className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg border border-emerald-200 dark:border-emerald-800"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </a>
                      )}

                      {caseItem && (
                        <button
                          onClick={() => onSelectCase(caseItem)}
                          className="px-2.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                        >
                          الملف
                        </button>
                      )}
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

    </div>
  );
};
