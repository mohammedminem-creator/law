import React, { useState, useMemo } from 'react';
import { X, Calendar, Clock, AlertTriangle, Check, DollarSign, User } from 'lucide-react';
import { ConsultationItem, CourtSession, CaseItem } from '../types/legal';
import { formatDateArabic } from '../utils/storage';

interface NewConsultationModalProps {
  sessions: CourtSession[];
  cases: CaseItem[];
  isOpen: boolean;
  onClose: () => void;
  onSave: (consultation: ConsultationItem) => void;
}

export const NewConsultationModal: React.FC<NewConsultationModalProps> = ({
  sessions,
  cases,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [clientName, setClientName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('17:00'); // Default to 5 PM after court hours
  const [durationMinutes, setDurationMinutes] = useState<number>(45);
  const [fee, setFee] = useState<number>(1000);
  const [isPaid, setIsPaid] = useState<boolean>(true);
  const [topic, setTopic] = useState('');
  const [notes, setNotes] = useState('');

  // Conflict check with court hearings on this date
  const conflictingCourtSessions = useMemo(() => {
    return sessions.filter(s => s.sessionDate === date);
  }, [sessions, date]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !phone.trim() || !topic.trim()) return;

    const newConsultation: ConsultationItem = {
      id: 'con-' + Date.now(),
      clientName: clientName.trim(),
      phone: phone.trim(),
      date,
      time,
      durationMinutes: Number(durationMinutes) || 45,
      fee: Number(fee) || 0,
      isPaid,
      topic: topic.trim(),
      status: 'مؤكدة',
      notes: notes.trim() || undefined,
    };

    onSave(newConsultation);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 overflow-y-auto">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 text-right">
        
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                حجز موعد استشارة بمكتب المحاماة
              </h3>
              <p className="text-[11px] text-slate-500">تنظيم مواعيد المقابلات لتجنب تضارب الجلسات</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Court conflict alert banner */}
        {conflictingCourtSessions.length > 0 && (
          <div className="p-3 mb-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">تنبيه مواعيد الجلسات:</span> لديك ({conflictingCourtSessions.length}) جلسة محكمة في هذا اليوم ({formatDateArabic(date)}). يُفضل تحديد الموعد بعد الساعة 3:00 مساءً.
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                اسم المستشير / الموكل *
              </label>
              <input
                type="text"
                required
                placeholder="الاسم"
                value={clientName}
                onChange={e => setClientName(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                رقم الهاتف (للتذكير) *
              </label>
              <input
                type="tel"
                required
                placeholder="01xxxxxxxxx"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                تاريخ المقابلة *
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div className="col-span-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                الوقت *
              </label>
              <input
                type="time"
                required
                value={time}
                onChange={e => setTime(e.target.value)}
                className="w-full px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div className="col-span-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                المدة (دقيقة)
              </label>
              <input
                type="number"
                min="15"
                step="15"
                value={durationMinutes}
                onChange={e => setDurationMinutes(Number(e.target.value))}
                className="w-full px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              موضوع الاستشارة القانونية *
            </label>
            <input
              type="text"
              required
              placeholder="مثال: استشارة تأسيس شركة، نزاع قسمة تركة، إفلاس..."
              value={topic}
              onChange={e => setTopic(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                رسم الاستشارة (ج.م)
              </label>
              <input
                type="number"
                min="0"
                step="100"
                value={fee}
                onChange={e => setFee(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div className="flex items-center pt-5">
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isPaid}
                  onChange={e => setIsPaid(e.target.checked)}
                  className="rounded text-amber-600 w-4 h-4"
                />
                <span>تم سداد رسم المقابلة</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              ملاحظات للمكتب
            </label>
            <input
              type="text"
              placeholder="المستندات المطلوب من العميل إحضارها معه..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-sm flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>تأكيد حجز المقابلة</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
