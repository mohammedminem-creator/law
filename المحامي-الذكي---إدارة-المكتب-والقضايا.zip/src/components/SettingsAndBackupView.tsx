import React, { useState, useRef } from 'react';
import {
  Settings,
  Shield,
  Lock,
  Download,
  Upload,
  RotateCcw,
  Building2,
  Check,
  AlertCircle,
  Wifi,
  WifiOff,
  Database,
  Smartphone,
} from 'lucide-react';
import { LawFirmProfile, SecuritySettings } from '../types/legal';
import { exportBackup, AppStateData } from '../utils/storage';

interface SettingsAndBackupViewProps {
  appState: AppStateData;
  firmProfile: LawFirmProfile;
  securitySettings: SecuritySettings;
  onUpdateProfile: (profile: LawFirmProfile) => void;
  onUpdateSecurity: (settings: SecuritySettings) => void;
  onRestoreBackup: (importedState: AppStateData) => void;
  onResetDefaults: () => void;
  isOnline: boolean;
  onLockScreenNow: () => void;
}

export const SettingsAndBackupView: React.FC<SettingsAndBackupViewProps> = ({
  appState,
  firmProfile,
  securitySettings,
  onUpdateProfile,
  onUpdateSecurity,
  onRestoreBackup,
  onResetDefaults,
  isOnline,
  onLockScreenNow,
}) => {
  // Profile edit states
  const [profile, setProfile] = useState<LawFirmProfile>(firmProfile);
  const [profileSaved, setProfileSaved] = useState(false);

  // Security edit states
  const [pinEnabled, setPinEnabled] = useState(securitySettings.pinEnabled);
  const [pinCode, setPinCode] = useState(securitySettings.pinCode);
  const [securitySaved, setSecuritySaved] = useState(false);
  const [pinError, setPinError] = useState<string | null>(null);

  // File input ref for backup restore
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(profile);
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2500);
  };

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinCode.length !== 4 || !/^\d{4}$/.test(pinCode)) {
      setPinError('يجب أن يتكون رمز PIN من 4 أرقام عددية');
      return;
    }
    setPinError(null);
    onUpdateSecurity({
      ...securitySettings,
      pinEnabled,
      pinCode,
    });
    setSecuritySaved(true);
    setTimeout(() => setSecuritySaved(false), 2500);
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.data && parsed.data.cases && parsed.data.sessions) {
          onRestoreBackup(parsed.data);
          setRestoreStatus('تم استعادة النسخة الاحتياطية بنجاح!');
        } else if (parsed.cases && parsed.sessions) {
          onRestoreBackup(parsed);
          setRestoreStatus('تم استعادة النسخة الاحتياطية بنجاح!');
        } else {
          setRestoreStatus('الملف غير صالح أو لا يحتوي على بنية بيانات المحامي الذكي.');
        }
      } catch (err) {
        console.error(err);
        setRestoreStatus('حدث خطأ في قراءة ملف النسخة الاحتياطية.');
      }
      setTimeout(() => setRestoreStatus(null), 4000);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-amber-600" />
          <span>الإعدادات، الأمان، والنسخ الاحتياطي</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          تخصيص بيانات المكتب والمطبوعات، حماية القضايا برمز PIN، والنسخ الاحتياطي بدون إنترنت
        </p>
      </div>

      {/* Offline and Storage Status Banner */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            isOnline ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600' : 'bg-amber-100 dark:bg-amber-950/40 text-amber-700'
          }`}>
            {isOnline ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">
              {isOnline ? 'متصل بالإنترنت ومفعل للذكاء الاصطناعي' : 'وضع العمل بدون إنترنت (Offline Mode) نشط'}
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              جميع القضايا والجلسات والمستندات والأتعاب محفوظة محلياً على جهازك ومتاحة بدون شبكة داخل قاعات المحكمة
            </p>
          </div>
        </div>

        <div className="text-xs font-bold text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 self-start sm:self-auto">
          قضايا: {appState.cases.length} · جلسات: {appState.sessions.length} · وثائق: {appState.documents.length}
        </div>
      </div>

      {/* Section 1: Security & PIN Code */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                حماية البيانات وقفل التطبيق (PIN Lock)
              </h3>
              <p className="text-[11px] text-slate-400">
                منع وصول المتطفلين لملفات الموكلين وقضاياهم
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onLockScreenNow}
            className="px-3 py-1.5 text-xs font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 rounded-lg border border-amber-200 dark:border-amber-800 flex items-center gap-1 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>قفل الشاشة الآن</span>
          </button>
        </div>

        <form onSubmit={handleSaveSecurity} className="space-y-3">
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={pinEnabled}
              onChange={e => setPinEnabled(e.target.checked)}
              className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
            />
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              تفعيل قفل التطبيق برمز PIN عند الفتح والخروج
            </span>
          </label>

          {pinEnabled && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  رمز PIN الحالي أو الجديد (4 أرقام) *
                </label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  value={pinCode}
                  onChange={e => setPinCode(e.target.value)}
                  placeholder="1234"
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-mono text-center tracking-widest"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs"
                >
                  {securitySaved ? 'تم حفظ رمز PIN بنجاح ✓' : 'حفظ إعدادات الأمان'}
                </button>
              </div>
            </div>
          )}

          {pinError && (
            <p className="text-xs text-red-500 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{pinError}</span>
            </p>
          )}
        </form>
      </div>

      {/* Section 2: Backup and Restore */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-600 flex items-center justify-center">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              النسخ الاحتياطي واستعادة البيانات (Backup & Restore)
            </h3>
            <p className="text-[11px] text-slate-400">
              حفظ نسخة كاملة من قضاياك على هاتفك أو Google Drive واستعادتها في أي وقت
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Export button */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Download className="w-4 h-4 text-emerald-600" />
              <span>تصدير نسخة احتياطية كاملة (JSON)</span>
            </h4>
            <p className="text-[11px] text-slate-500">
              تنزيل ملف يحتوي على كافة القضايا، الجلسات، الأتعاب، والمستندات للحفظ الآمن.
            </p>
            <button
              onClick={() => exportBackup(appState)}
              className="w-full py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-95 rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تنزيل ملف النسخة الاحتياطية الآن</span>
            </button>
          </div>

          {/* Import / Restore button */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-blue-600" />
              <span>استعادة نسخة احتياطية سابقة</span>
            </h4>
            <p className="text-[11px] text-slate-500">
              رفع ملف النسخة الاحتياطية واسترجاع كافة البيانات فوراً عند تغيير الجهاز.
            </p>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-2 text-xs font-bold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 rounded-xl shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>اختيار ملف النسخة الاحتياطية</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileRestore}
              className="hidden"
            />
          </div>
        </div>

        {restoreStatus && (
          <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs text-blue-800 dark:text-blue-300 flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>{restoreStatus}</span>
          </div>
        )}

        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs">
          <span className="text-slate-400">إعادة تعيين القضايا للبيانات الافتراضية النموذجية:</span>
          <button
            onClick={() => {
              if (confirm('هل أنت متأكد من رغبتك في استعادة البيانات الافتراضية للمكتب؟')) {
                onResetDefaults();
              }
            }}
            className="text-xs font-semibold text-red-600 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة البيانات النموذجية</span>
          </button>
        </div>
      </div>

      {/* Section 3: Law Firm & Lawyer Profile */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              بيانات المحامي والمكتب (تظهر على سندات القبض والرول)
            </h3>
            <p className="text-[11px] text-slate-400">
              تظهر هذه البيانات في ترويسة سندات القبض، رول الجلسات، والمذكرات القانونية
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1">اسم المحامي المسؤول *</label>
              <input
                type="text"
                required
                value={profile.lawyerName}
                onChange={e => setProfile({ ...profile, lawyerName: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">الدرجة والصفة القضائية *</label>
              <input
                type="text"
                required
                value={profile.title}
                onChange={e => setProfile({ ...profile, title: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">اسم المكتب / المؤسسة القانونية *</label>
              <input
                type="text"
                required
                value={profile.firmName}
                onChange={e => setProfile({ ...profile, firmName: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">رقم القيد بنقابة المحامين *</label>
              <input
                type="text"
                required
                value={profile.barNumber}
                onChange={e => setProfile({ ...profile, barNumber: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">رقم الهاتف الأساسي (01006580460)</label>
              <input
                type="tel"
                value={profile.phone}
                onChange={e => setProfile({ ...profile, phone: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">رقم الهاتف الإضافي (01558866646)</label>
              <input
                type="tel"
                value={profile.secondaryPhone || ''}
                onChange={e => setProfile({ ...profile, secondaryPhone: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">البريد الإلكتروني للبرنامج / المكتب</label>
              <input
                type="email"
                value={profile.email}
                onChange={e => setProfile({ ...profile, email: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold mb-1">شعار / عبارة المكتب (معكم .. في كل قضية)</label>
              <input
                type="text"
                value={profile.slogan || ''}
                onChange={e => setProfile({ ...profile, slogan: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold mb-1">عنوان مقر المكتب</label>
              <input
                type="text"
                value={profile.address}
                onChange={e => setProfile({ ...profile, address: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs"
            >
              {profileSaved ? 'تم حفظ بيانات المكتب بنجاح ✓' : 'حفظ تعديلات المكتب'}
            </button>
          </div>
        </form>
      </div>

    </div>
  );
};
