import React, { useState, useRef } from 'react';
import { X, Upload, Camera, FileText, Check, Shield, AlertCircle } from 'lucide-react';
import { CaseDocument, CaseItem } from '../types/legal';

interface NewDocumentModalProps {
  cases: CaseItem[];
  defaultCaseId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSave: (doc: CaseDocument) => void;
}

const DOC_TYPES: CaseDocument['docType'][] = [
  'توكيل رسمي',
  'صحيفة دعوى / عريضة',
  'مذكرة دفاع',
  'محضر شرطة',
  'حكم قضائي',
  'تقرير خبير',
  'مستند إثبات / عقد',
  'إنذار رسمي',
  'إيصال سداد',
  'أخرى',
];

export const NewDocumentModal: React.FC<NewDocumentModalProps> = ({
  cases,
  defaultCaseId,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [caseId, setCaseId] = useState(defaultCaseId || cases[0]?.id || '');
  const [title, setTitle] = useState('');
  const [docType, setDocType] = useState<CaseDocument['docType']>('توكيل رسمي');
  const [powerOfAttorneyNumber, setPowerOfAttorneyNumber] = useState('');
  const [notaryOffice, setNotaryOffice] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  // File & Camera states
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [fileData, setFileData] = useState<string | undefined>(undefined);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      setFileSize((file.size / 1024).toFixed(1) + ' KB');
      if (!title) {
        setTitle(file.name.replace(/\.[^/.]+$/, ''));
      }
      const reader = new FileReader();
      reader.onload = event => {
        setFileData(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      setCameraError(null);
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError('تعذر فتح الكاميرا، يرجى اختيار ملف أو صورة من الجهاز');
      setIsCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setFileData(dataUrl);
        setFileName(`Scan_${Date.now()}.jpg`);
        setFileSize('~450 KB');
        if (!title) setTitle(`مسح ضوئي - ${docType}`);
      }
      // Stop camera stream
      const stream = videoRef.current.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
    }
    setIsCameraActive(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseId || !title.trim()) return;

    const newDoc: CaseDocument = {
      id: 'doc-' + Date.now(),
      caseId,
      title: title.trim(),
      docType,
      powerOfAttorneyNumber: docType === 'توكيل رسمي' ? powerOfAttorneyNumber.trim() : undefined,
      notaryOffice: docType === 'توكيل رسمي' ? notaryOffice.trim() : undefined,
      date,
      fileData,
      fileName: fileName || `${title.trim()}.pdf`,
      fileSize: fileSize || '1.1 MB',
      uploadedAt: new Date().toISOString().split('T')[0],
      notes: notes.trim() || undefined,
    };

    onSave(newDoc);
    stopCamera();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 text-right">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                أرشفة مستند جديد
              </h3>
              <p className="text-[11px] text-slate-500">
                رفع ملف، صورة، أو مسح ضوئي بكاميرا الهاتف
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          
          {/* Select Case */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              ملف القضية التابع لها المستند *
            </label>
            <select
              required
              value={caseId}
              onChange={e => setCaseId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            >
              {cases.map(c => (
                <option key={c.id} value={c.id}>
                  قضية {c.caseNumber}/{c.year} - {c.clientName} ({c.caseType})
                </option>
              ))}
            </select>
          </div>

          {/* Doc Title & Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                عنوان المستند *
              </label>
              <input
                type="text"
                required
                placeholder="مثال: توكيل قضايا رسمي عام..."
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                نوع المستند *
              </label>
              <select
                value={docType}
                onChange={e => setDocType(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              >
                {DOC_TYPES.map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Power of Attorney specific fields */}
          {docType === 'توكيل رسمي' && (
            <div className="p-3 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-amber-900 dark:text-amber-300 mb-1">
                  رقم التوكيل والحرف والسنة
                </label>
                <input
                  type="text"
                  placeholder="مثال: 4120 ب لسنة 2026"
                  value={powerOfAttorneyNumber}
                  onChange={e => setPowerOfAttorneyNumber(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-800 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-amber-900 dark:text-amber-300 mb-1">
                  مكتب التوثيق (الشهر العقاري)
                </label>
                <input
                  type="text"
                  placeholder="مثال: توثيق الأهرام النموذجي"
                  value={notaryOffice}
                  onChange={e => setNotaryOffice(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-800 rounded-lg"
                />
              </div>
            </div>
          )}

          {/* Upload or Camera scan zone */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              إرفاق الوثيقة (ملف أو مسح ضوئي)
            </label>

            {isCameraActive ? (
              <div className="relative rounded-xl overflow-hidden bg-black p-1 text-center">
                <video ref={videoRef} autoPlay playsInline className="w-full h-48 object-cover rounded-lg" />
                <div className="flex justify-center gap-2 mt-2 pb-1">
                  <button
                    type="button"
                    onClick={capturePhoto}
                    className="px-4 py-1.5 text-xs font-bold bg-amber-600 text-white rounded-lg flex items-center gap-1 cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                    <span>التقاط المسح الضوئي</span>
                  </button>
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="px-3 py-1.5 text-xs text-white bg-slate-700 rounded-lg cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-3 border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-amber-500 rounded-xl flex flex-col items-center justify-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-amber-600 transition-colors cursor-pointer"
                >
                  <Upload className="w-5 h-5 text-amber-600" />
                  <span className="text-xs font-bold">اختيار ملف أو PDF</span>
                  <span className="text-[10px] text-slate-400">PDF, JPG, PNG</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,.pdf"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={startCamera}
                  className="p-3 border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-amber-500 rounded-xl flex flex-col items-center justify-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-amber-600 transition-colors cursor-pointer"
                >
                  <Camera className="w-5 h-5 text-amber-600" />
                  <span className="text-xs font-bold">مسح ضوئي بالكاميرا</span>
                  <span className="text-[10px] text-slate-400">تصوير الأوراق مباشرة</span>
                </button>
              </div>
            )}

            {cameraError && (
              <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{cameraError}</span>
              </p>
            )}

            {fileName && (
              <div className="mt-2 p-2 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 rounded-lg flex items-center justify-between text-xs text-emerald-800 dark:text-emerald-300">
                <div className="flex items-center gap-1.5 truncate">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="truncate">{fileName}</span>
                  <span className="text-[10px] text-slate-400">({fileSize})</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setFileName('');
                    setFileData(undefined);
                  }}
                  className="text-xs text-red-500 hover:underline mr-2 shrink-0"
                >
                  إزالة
                </button>
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              ملاحظات الفهرسة والأرشيف
            </label>
            <input
              type="text"
              placeholder="مثال: أصل التوكيل محفوظ بالخزينة الحديدية للمكتب..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => {
                stopCamera();
                onClose();
              }}
              className="px-3.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-sm flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>أرشفة المستند</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
