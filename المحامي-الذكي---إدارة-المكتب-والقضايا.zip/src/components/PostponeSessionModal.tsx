import React, { useState } from 'react';
import { X, Calendar, Clock, AlertTriangle, MessageSquare, History, Check } from 'lucide-react';
import { CourtSession, CaseItem, PostponementRecord } from '../types/legal';
import { formatDateArabic, createWhatsAppUrl } from '../utils/storage';

interface PostponeSessionModalProps {
  session: CourtSession;
  caseItem?: CaseItem;
  isOpen: boolean;
  onClose: () => void;
  onPostpone: (sessionId: string, newDate: string, reason: string, notes?: string) => void;
}

const COMMON_REASONS = [
  'للاطلاع وتقديم المستندات والمذكرات',
  'لإعادة الإعلان وعرض الصلح',
  'لحضور المتهم بشخصه وسماع أقواله',
  'للمرافعة الشفوية الختامية',
  'لحجز الدعوى للحكم وإيداع المذكرات',
  'لورود تقرير مكتب خبراء وزارة العدل',
  'لضم مفردات الجناية / المحضر الإداري',
  'للصلح وسداد المبلغ المتنازع عليه',
  'لإعلان الخصم بالطلبات العارضة والمدعي بالحق المدني',
  'لعدم حضور القاضي / تعذر انعقاد الدائرة',
];

export const PostponeSessionModal: React.FC<PostponeSessionModalProps> = ({
  session,
  caseItem,
  isOpen,
  onClose,
  onPostpone,
}) => {
  if (!isOpen) return null;

  // Default next date: 2 to 3 weeks later
  const getDefaultNextDate = () => {
    const d = new Date(session.sessionDate || new Date());
    d.setDate(d.getDate() + 21);
    return d.toISOString().split('T')[0];
  };

  const [newDate, setNewDate] = useState<string>(getDefaultNextDate());
  const [reason, setReason] = useState<string>('');
  const [lawyerNotes, setLawyerNotes] = useState<string>('');
  const [notifyWhatsApp, setNotifyWhatsApp] = useState<boolean>(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDate || !reason.trim()) return;

    onPostpone(session.id, newDate, reason.trim(), lawyerNotes.trim());

    if (notifyWhatsApp && caseItem?.clientPhone) {
      const msgText = `السلام عليكم ورحمة الله وبركاته،
أستاذ/ة ${caseItem.clientName}،
نود إحاطتكم علماً بمستجدات جلستكم في القضية رقم (${caseItem.caseNumber} لسنة ${caseItem.year}) بمحكمة (${caseItem.court}):
- تم تأجيل نظر الدعوى إلى جلسة: ${formatDateArabic(newDate)}
- سبب التأجيل: ${reason.trim()}
مكتبنا يتابع كافة الإجراءات القانونية اللازمة لصالح القضية. دمتم بخير.`;
      const waUrl = createWhatsAppUrl(caseItem.clientPhone, msgText);
      window.open(waUrl, '_blank');
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-right">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                تأجيل الجلسة وتوثيق السبب
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                تسجيل موعد الجلسة القادمة وحفظ سجل التأجيلات للقضية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Case Info Banner */}
        {caseItem && (
          <div className="p-3.5 mb-5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 dark:text-slate-100">
                قضية رقم {caseItem.caseNumber} لسنة {caseItem.year} - {caseItem.caseType}
              </span>
              <span className="text-amber-700 dark:text-amber-400 font-semibold">
                {caseItem.court}
              </span>
            </div>
            <div className="text-slate-600 dark:text-slate-400 flex items-center justify-between">
              <span>الموكل: <strong>{caseItem.clientName}</strong> ({caseItem.clientRole})</span>
              <span>الخصم: <strong>{caseItem.opponentName}</strong></span>
            </div>
            <div className="text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200 dark:border-slate-700">
              تاريخ الجلسة الحالية: <strong className="text-slate-800 dark:text-slate-200">{formatDateArabic(session.sessionDate)}</strong> (قرار سابق: {session.decisionOrReason})
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* New Date */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              تاريخ الجلسة القادمة (تاريخ التأجيل) *
            </label>
            <div className="relative">
              <input
                type="date"
                required
                value={newDate}
                onChange={e => setNewDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-none dark:text-white"
              />
            </div>
            {newDate && (
              <p className="mt-1 text-xs text-amber-700 dark:text-amber-400 font-medium">
                {formatDateArabic(newDate)}
              </p>
            )}
          </div>

          {/* Reason Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              سبب التأجيل أو قرار المحكمة *
            </label>
            <input
              type="text"
              required
              placeholder="مثال: للاطلاع والمستندات، لإعادة الإعلان، لحضور المتهم..."
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-none dark:text-white"
            />
          </div>

          {/* Quick Reason Suggestions */}
          <div>
            <span className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
              أسباب دارجة (اضغط للاختيار السريع):
            </span>
            <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-1">
              {COMMON_REASONS.map(r => (
                <button
                  type="button"
                  key={r}
                  onClick={() => setReason(r)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition-colors text-right ${
                    reason === r
                      ? 'bg-amber-600 text-white border-amber-600'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Lawyer Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              ملاحظات وتكليفات الجلسة القادمة (للمحامي والمساعدين)
            </label>
            <textarea
              rows={2}
              placeholder="مثال: سداد أمانة الخبير بخزينة المحكمة واستخراج شهادة سداد قبل الجلسة بيومين..."
              value={lawyerNotes}
              onChange={e => setLawyerNotes(e.target.value)}
              className="w-full px-3.5 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-none dark:text-white"
            />
          </div>

          {/* WhatsApp Notification Checkbox */}
          {caseItem?.clientPhone && (
            <label className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 cursor-pointer">
              <input
                type="checkbox"
                checked={notifyWhatsApp}
                onChange={e => setNotifyWhatsApp(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
              />
              <div className="flex items-center gap-1.5 text-xs text-emerald-800 dark:text-emerald-300 font-medium">
                <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                <span>فتح واتساب لإرسال إخطار رسمي للموكل ({caseItem.clientPhone}) بالتأجيل فور الحفظ</span>
              </div>
            </label>
          )}

          {/* Postponement History Timeline */}
          {session.postponementHistory && session.postponementHistory.length > 0 && (
            <div className="pt-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                <History className="w-4 h-4 text-amber-600" />
                <span>سجل التأجيلات السابقة لهذه القضية ({session.postponementHistory.length}):</span>
              </div>
              <div className="space-y-1.5 max-h-32 overflow-y-auto pl-1">
                {session.postponementHistory.map((post, idx) => (
                  <div
                    key={post.id || idx}
                    className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 text-[11px] text-slate-600 dark:text-slate-300"
                  >
                    <div className="flex justify-between font-semibold text-slate-800 dark:text-slate-200">
                      <span>من: {formatDateArabic(post.fromDate)} ← إلى: {formatDateArabic(post.toDate)}</span>
                      <span className="text-[10px] text-slate-400">{post.postponedAt}</span>
                    </div>
                    <p className="mt-0.5 text-amber-700 dark:text-amber-400">السبب: {post.reason}</p>
                    {post.notes && <p className="text-slate-500 dark:text-slate-400 italic">ملاحظة: {post.notes}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-xl transition-all shadow-md shadow-amber-600/20 flex items-center gap-1.5 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>تأكيد وحفظ التأجيل</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
