import React from 'react';
import { X, Printer, Scale, CheckCircle } from 'lucide-react';
import { PaymentRecord, CaseItem, LawFirmProfile } from '../types/legal';
import { formatDateArabic, formatCurrency } from '../utils/storage';

interface ReceiptPrintModalProps {
  payment: PaymentRecord;
  caseItem: CaseItem;
  firmProfile: LawFirmProfile;
  isOpen: boolean;
  onClose: () => void;
  totalPaid: number;
}

export const ReceiptPrintModal: React.FC<ReceiptPrintModalProps> = ({
  payment,
  caseItem,
  firmProfile,
  isOpen,
  onClose,
  totalPaid,
}) => {
  if (!isOpen) return null;

  const remaining = Math.max(0, caseItem.totalFee - totalPaid);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-right">
        
        {/* Controls - Hide on Print */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4 no-print">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة سند القبض</span>
            </button>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Official Receipt Body */}
        <div className="p-6 border-2 border-slate-900 dark:border-slate-300 rounded-xl bg-white text-slate-900 print:border-slate-900 print:text-black">
          
          {/* Header */}
          <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4 mb-4">
            <div>
              <h2 className="text-lg font-black text-slate-900 leading-tight">
                {firmProfile.firmName}
              </h2>
              <h3 className="text-sm font-bold text-slate-800">
                {firmProfile.lawyerName} - {firmProfile.title}
              </h3>
              <p className="text-[11px] text-slate-600">
                {firmProfile.barNumber} {firmProfile.taxNumber && `· بطاقة ضريبية: ${firmProfile.taxNumber}`}
              </p>
              <p className="text-[11px] text-slate-700 font-bold">
                هاتف: <span className="font-mono">{firmProfile.phone}</span>
                {firmProfile.secondaryPhone && <span> / <span className="font-mono">{firmProfile.secondaryPhone}</span></span>}
              </p>
            </div>
            <div className="text-left shrink-0">
              <div className="w-14 h-14 rounded-xl overflow-hidden border border-slate-900 mb-1 ml-auto bg-slate-950">
                <img
                  src={firmProfile.logoUrl || '/assets/aistudio/____________________________a39fbca1.png'}
                  alt={firmProfile.firmName}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-xs font-mono font-bold text-slate-800">
                {payment.receiptNumber}
              </div>
              <div className="text-[11px] text-slate-600">
                {formatDateArabic(payment.date)}
              </div>
            </div>
          </div>

          {/* Title */}
          <div className="text-center my-3">
            <span className="inline-block px-4 py-1 text-sm font-black tracking-wider bg-slate-100 border border-slate-400 rounded-md">
              سـنـد قـبـض أتعـــاب محامـــاة
            </span>
          </div>

          {/* Content Rows */}
          <div className="space-y-3 text-xs leading-relaxed my-5">
            <div className="flex items-baseline">
              <span className="font-bold min-w-28">استلمنا من السيد/ة:</span>
              <span className="flex-1 border-b border-dotted border-slate-400 font-bold text-sm px-2">
                {caseItem.clientName}
              </span>
            </div>

            <div className="flex items-baseline">
              <span className="font-bold min-w-28">مبلغاً وقدره:</span>
              <span className="flex-1 border-b border-dotted border-slate-400 font-black text-sm px-2 text-amber-900">
                {formatCurrency(payment.amount)}
              </span>
            </div>

            <div className="flex items-baseline">
              <span className="font-bold min-w-28">طريقة السداد:</span>
              <span className="flex-1 border-b border-dotted border-slate-400 px-2 font-medium">
                {payment.paymentMethod}
              </span>
            </div>

            <div className="flex items-baseline">
              <span className="font-bold min-w-28">وذلك عن أتعاب:</span>
              <span className="flex-1 border-b border-dotted border-slate-400 px-2">
                القضية رقم ({caseItem.caseNumber} لسنة {caseItem.year} - {caseItem.caseType}) المنظورة أمام ({caseItem.court})
              </span>
            </div>

            {payment.notes && (
              <div className="flex items-baseline">
                <span className="font-bold min-w-28">ملاحظات وبيان:</span>
                <span className="flex-1 border-b border-dotted border-slate-400 px-2 italic">
                  {payment.notes}
                </span>
              </div>
            )}
          </div>

          {/* Financial summary bar */}
          <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg grid grid-cols-3 gap-2 text-center text-xs my-4">
            <div>
              <span className="text-slate-600 block text-[10px]">إجمالي الأتعاب</span>
              <span className="font-bold tabular-nums">{formatCurrency(caseItem.totalFee)}</span>
            </div>
            <div>
              <span className="text-slate-600 block text-[10px]">إجمالي المسدد حتى تاريخه</span>
              <span className="font-bold text-emerald-800 tabular-nums">{formatCurrency(totalPaid)}</span>
            </div>
            <div>
              <span className="text-slate-600 block text-[10px]">الرصيد المتبقي</span>
              <span className="font-bold text-amber-800 tabular-nums">{formatCurrency(remaining)}</span>
            </div>
          </div>

          {/* Signatures */}
          <div className="flex justify-between items-end pt-6 mt-4 border-t border-slate-300 text-xs">
            <div className="text-center w-36">
              <p className="font-semibold text-slate-700 mb-8">توقيع المستلم</p>
              <p className="border-t border-slate-400 pt-1 font-bold">{payment.receivedBy || firmProfile.lawyerName}</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 rounded-full border-2 border-dashed border-amber-700/60 flex items-center justify-center text-[10px] text-amber-800 font-bold rotate-12">
                خاتم المكتب
              </div>
            </div>

            <div className="text-center w-36">
              <p className="font-semibold text-slate-700 mb-8">اعتماد المحامي المسؤول</p>
              <p className="border-t border-slate-400 pt-1 font-bold">{firmProfile.lawyerName}</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
