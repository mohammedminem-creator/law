import React from 'react';
import {
  Scale,
  Plus,
  Lock,
  Moon,
  Sun,
  Wifi,
  WifiOff,
  Calendar,
  Briefcase,
  FileText,
  DollarSign,
  Users,
  Sparkles,
  Settings,
  Phone,
  RefreshCw,
} from 'lucide-react';
import { LawFirmProfile } from '../types/legal';

export type NavTab =
  | 'dashboard'
  | 'cases'
  | 'docket'
  | 'documents'
  | 'financials'
  | 'clients'
  | 'ai_assistant'
  | 'settings';

interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenNewCase: () => void;
  onLockApp: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  isOnline: boolean;
  todaySessionsCount: number;
  firmProfile: LawFirmProfile;
  isSyncing?: boolean;
  onManualSync?: () => void;
  lastSyncTime?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenNewCase,
  onLockApp,
  isDarkMode,
  onToggleDarkMode,
  isOnline,
  todaySessionsCount,
  firmProfile,
  isSyncing = false,
  onManualSync,
  lastSyncTime,
}) => {
  const navItems: { id: NavTab; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'dashboard', label: 'الرئيسية', icon: Briefcase },
    { id: 'cases', label: 'القضايا', icon: FileText },
    { id: 'docket', label: 'رول الجلسات والأجندة', icon: Calendar },
    { id: 'documents', label: 'الأرشيف الإلكتروني', icon: FileText },
    { id: 'financials', label: 'المالية والأتعاب', icon: DollarSign },
    { id: 'clients', label: 'الموكلين والاستشارات', icon: Users },
    { id: 'ai_assistant', label: 'المساعد القانوني الذكي', icon: Sparkles },
    { id: 'settings', label: 'الإعدادات والنسخ', icon: Settings },
  ];

  const logoSrc = firmProfile.logoUrl || '/assets/aistudio/____________________________a39fbca1.png';

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-amber-500/20 shadow-xs transition-colors no-print">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          
          {/* Brand Zone with Official Board Logo */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onSelectTab('dashboard')}
              className="flex items-center gap-2.5 text-right group cursor-pointer focus:outline-none"
            >
              <div className="relative w-11 h-11 rounded-xl overflow-hidden border-2 border-amber-500 shadow-md shadow-amber-900/10 shrink-0 bg-slate-950">
                <img
                  src={logoSrc}
                  alt={firmProfile.firmName}
                  className="w-full h-full object-cover object-top"
                  onError={e => {
                    // Fallback to scale icon if image fails
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>

              <div className="flex flex-col">
                <span className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white leading-tight">
                  {firmProfile.firmName}
                </span>
                <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-700 dark:text-amber-400">
                  <span>{firmProfile.title}</span>
                  <span className="hidden md:inline">· هاتف: {firmProfile.phone}</span>
                </div>
              </div>
            </button>
          </div>

          {/* Nav Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map(item => {
              const isActive = currentTab === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`flex items-center gap-1.5 px-2.5 xl:px-3 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 relative ${
                    isActive
                      ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                  {item.id === 'docket' && todaySessionsCount > 0 && (
                    <span className="mr-1 px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-amber-600 text-white">
                      {todaySessionsCount}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-amber-600 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Zone */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            
            {/* Multi-Device Cloud Sync Status Button */}
            <button
              onClick={onManualSync}
              title={`مزامنة سحابية بين جميع أجهزتك (الكمبيوتر والموبايل) ${lastSyncTime ? '· آخر مزامنة: ' + lastSyncTime : ''}`}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/50 hover:bg-emerald-100 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-emerald-600' : ''}`} />
              <span className="hidden sm:inline">أجهزتك متصلة</span>
            </button>

            {/* Quick Action: New Case */}
            <button
              onClick={onOpenNewCase}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-lg transition-all shadow-sm shadow-amber-600/20 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>تسجيل قضية</span>
            </button>

            {/* Dark mode toggle */}
            <button
              onClick={onToggleDarkMode}
              title={isDarkMode ? 'الوضع الفاتح' : 'الوضع الليلي'}
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Quick Lock */}
            <button
              onClick={onLockApp}
              title="قفل التطبيق برمز PIN"
              className="p-2 text-slate-500 hover:text-amber-700 dark:text-slate-400 dark:hover:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Horizontal Sub-Navigation */}
      <div className="lg:hidden overflow-x-auto border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-900/90 px-2 py-1.5 flex gap-1 no-scrollbar">
        {navItems.map(item => {
          const isActive = currentTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
              {item.id === 'docket' && todaySessionsCount > 0 && (
                <span className={`px-1 text-[10px] rounded-full ${isActive ? 'bg-white text-amber-600' : 'bg-amber-600 text-white'}`}>
                  {todaySessionsCount}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
