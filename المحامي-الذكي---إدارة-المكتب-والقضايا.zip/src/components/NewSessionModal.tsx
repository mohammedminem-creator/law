import React, { useState } from 'react';
import { X, Calendar, Plus } from 'lucide-react';
import { CourtSession, CaseItem } from '../types/legal';

interface NewSessionModalProps {
  cases: CaseItem[];
  defaultCaseId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSave: (session: CourtSession) => void;
}

export const NewSessionModal: React.FC<NewSessionModalProps> = ({
  cases,
  defaultCaseId,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [caseId, setCaseId] = useState(defaultCaseId || cases[0]?.id || '');
  const [sessionDate, setSessionDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [sessionTime, setSessionTime] = useState('10:00');
  const [courtroom, setCourtroom] = useState('قاعة 3');
  const [chamber, setChamber] = useState('');
  const [rollNumber, setRollNumber] = useState<number | undefined>(undefined);
  const [decisionOrReason, setDecisionOrReason] = useState('للاطلاع والمستندات وتقديم المذكرات');
  const [lawyerNotes, setLawyerNotes] = useState('');

  const selectedCase = cases.find(c => c.id === caseId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseId || !sessionDate || !decisionOrReason.trim()) return;

    const newSession: CourtSession = {
      id: 'sess-' + Date.now(),
      caseId,
      sessionDate,
      sessionTime,
      courtroom: courtroom.trim() || undefined,
      chamber: chamber.trim() || selectedCase?.circuit || undefined,
      rollNumber: rollNumber ? Number(rollNumber) : undefined,
      decisionOrReason: decisionOrReason.trim(),
      isCompleted: false,
      postponementHistory: [],
      lawyerNotes: lawyerNotes.trim() || undefined,
    };

    onSave(newSession);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-3 overflow-y-auto">
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 text-right">
        
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                إضافة موعد جلسة جديدة
              </h3>
              <p className="text-[11px] text-slate-500">تسجيل الجلسة بالأجندة ورول المحكمة</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              القضية *
            </label>
            <select
              required
              value={caseId}
              onChange={e => setCaseId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            >
              {cases.map(c => (
                <option key={c.id} value={c.id}>
                  قضية {c.caseNumber}/{c.year} - {c.clientName} ({c.court})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                تاريخ الجلسة *
              </label>
              <input
                type="date"
                required
                value={sessionDate}
                onChange={e => setSessionDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                وقت انعقاد الجلسة
              </label>
              <input
                type="time"
                value={sessionTime}
                onChange={e => setSessionTime(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                القاعة / الغرفة
              </label>
              <input
                type="text"
                placeholder="قاعة 3 مدني"
                value={courtroom}
                onChange={e => setCourtroom(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                رقم الرول بالجلسة
              </label>
              <input
                type="number"
                min="1"
                placeholder="رقم الرول"
                value={rollNumber || ''}
                onChange={e => setRollNumber(e.target.value ? Number(e.target.value) : undefined)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              القرار المطلوب أو سبب الجلسة *
            </label>
            <input
              type="text"
              required
              placeholder="مثال: للمرافعة وتقديم المذكرات..."
              value={decisionOrReason}
              onChange={e => setDecisionOrReason(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              ملاحظات للمحامي الحاضر
            </label>
            <textarea
              rows={2}
              placeholder="تعليمات خاصة بالحضور أو المستندات المطلوب تسليمها للقاضي..."
              value={lawyerNotes}
              onChange={e => setLawyerNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-xl"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-sm flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>إدراج الجلسة</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
