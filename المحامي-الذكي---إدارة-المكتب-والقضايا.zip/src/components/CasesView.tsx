import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Plus,
  Briefcase,
  Calendar,
  History,
  FileText,
  DollarSign,
  User,
  Building2,
  ChevronLeft,
  MessageSquare,
  Scale,
  Printer,
} from 'lucide-react';
import { CaseItem, CourtSession, CaseType, CaseStatus } from '../types/legal';
import { formatDateArabic, formatCurrency, createWhatsAppUrl } from '../utils/storage';

interface CasesViewProps {
  cases: CaseItem[];
  sessions: CourtSession[];
  onOpenNewCase: () => void;
  onSelectCase: (caseItem: CaseItem) => void;
  onOpenPostponeModal: (session: CourtSession) => void;
}

export const CasesView: React.FC<CasesViewProps> = ({
  cases,
  sessions,
  onOpenNewCase,
  onSelectCase,
  onOpenPostponeModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  const todayStr = new Date().toISOString().split('T')[0];

  const handlePrintCases = () => {
    window.print();
  };

  // Helper to find the latest or upcoming session for each case
  const getLatestSession = (caseId: string) => {
    const caseSessions = sessions.filter(s => s.caseId === caseId);
    if (caseSessions.length === 0) return null;
    // Prefer upcoming sessions first
    const upcoming = caseSessions
      .filter(s => s.sessionDate >= todayStr)
      .sort((a, b) => new Date(a.sessionDate).getTime() - new Date(b.sessionDate).getTime());
    if (upcoming.length > 0) return upcoming[0];
    // Otherwise return most recent past session
    return caseSessions.sort(
      (a, b) => new Date(b.sessionDate).getTime() - new Date(a.sessionDate).getTime()
    )[0];
  };

  // Filtered cases
  const filteredCases = useMemo(() => {
    return cases.filter(c => {
      const matchSearch =
        searchQuery === '' ||
        c.caseNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.year.toString().includes(searchQuery) ||
        c.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.opponentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.court.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.subject.toLowerCase().includes(searchQuery.toLowerCase());

      const matchType = selectedType === 'all' || c.caseType === selectedType;
      const matchStatus = selectedStatus === 'all' || c.status === selectedStatus;

      return matchSearch && matchType && matchStatus;
    });
  }, [cases, searchQuery, selectedType, selectedStatus]);

  // Unique case types for filter
  const uniqueTypes = useMemo(() => {
    return Array.from(new Set(cases.map(c => c.caseType)));
  }, [cases]);

  return (
    <div className="space-y-5">
      
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-amber-600" />
            <span>سجل القضايا والدعاوى ({filteredCases.length})</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            فهرس القضايا المقيدة بالمكتب، ومتابعة المحاكم والأطراف ومواعيد الجلسات
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={handlePrintCases}
            className="px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-600" />
            <span>طباعة كشف القضايا</span>
          </button>

          <button
            onClick={onOpenNewCase}
            className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-xl shadow-sm shadow-amber-600/20 flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل قضية جديدة</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row gap-2.5">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
            <input
              type="text"
              placeholder="ابحث برقم القضية، السنة، اسم الموكل، الخصم، أو المحكمة..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 dark:text-white"
            />
          </div>

          {/* Type filter */}
          <select
            value={selectedType}
            onChange={e => setSelectedType(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg dark:text-white"
          >
            <option value="all">جميع أنواع القضايا</option>
            {uniqueTypes.map(t => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>

          {/* Status filter */}
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg dark:text-white"
          >
            <option value="all">جميع الحالات</option>
            <option value="جارية">جارية</option>
            <option value="مؤجلة">مؤجلة</option>
            <option value="محكومة">محكومة</option>
            <option value="صلح">صلح</option>
            <option value="مشطوبة">مشطوبة</option>
          </select>
        </div>
      </div>

      {/* Cases Grid */}
      {filteredCases.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <Briefcase className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
            لم يتم العثور على قضايا مطابقة
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            جرب تعديل كلمات البحث أو الفلاتر، أو قم بتسجيل قضية جديدة.
          </p>
          <button
            onClick={onOpenNewCase}
            className="mt-4 px-4 py-2 text-xs font-bold text-amber-600 border border-amber-600 rounded-xl hover:bg-amber-50"
          >
            + تسجيل قضية جديدة
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCases.map(c => {
            const nextSession = getLatestSession(c.id);
            const isUpcoming = nextSession && nextSession.sessionDate >= todayStr;

            return (
              <div
                key={c.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-600/70 transition-all shadow-xs flex flex-col justify-between"
              >
                <div>
                  {/* Top Bar: Case No & Badge */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-black text-slate-900 dark:text-white">
                          قضية {c.caseNumber} لسنة {c.year}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-400">
                          {c.caseType}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        {c.court} {c.circuit && `· ${c.circuit}`}
                      </div>
                    </div>

                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                        c.status === 'جارية'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/50 dark:text-blue-300'
                          : c.status === 'صلح' || c.status === 'محكومة'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {c.status}
                    </span>
                  </div>

                  {/* Parties */}
                  <div className="p-2.5 my-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600 dark:text-slate-300">
                        <strong>الموكل:</strong> {c.clientName} ({c.clientRole})
                      </span>
                      {c.clientPhone && (
                        <a
                          href={createWhatsAppUrl(
                            c.clientPhone,
                            `السلام عليكم أستاذ/ة ${c.clientName}، بخصوص القضية رقم ${c.caseNumber}/${c.year} بمحكمة ${c.court}:`
                          )}
                          target="_blank"
                          rel="noreferrer"
                          title="محادثة واتساب"
                          className="text-emerald-600 hover:text-emerald-700 flex items-center gap-1 text-[11px]"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>واتساب</span>
                        </a>
                      )}
                    </div>
                    <div className="text-slate-500 dark:text-slate-400 truncate">
                      <strong>الخصم:</strong> {c.opponentName} {c.opponentLawyer && `(محاميه: ${c.opponentLawyer})`}
                    </div>
                  </div>

                  {/* Subject */}
                  <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2 mb-3">
                    {c.subject}
                  </p>

                  {/* Session Status Banner */}
                  {nextSession && (
                    <div
                      className={`p-2 rounded-xl text-xs flex items-center justify-between mb-3 ${
                        isUpcoming
                          ? 'bg-amber-50 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 border border-amber-200 dark:border-amber-800/40'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 truncate">
                        <Calendar className="w-3.5 h-3.5 shrink-0 text-amber-600" />
                        <span className="truncate">
                          جلسة: {formatDateArabic(nextSession.sessionDate)} ({nextSession.decisionOrReason})
                        </span>
                      </div>

                      <button
                        onClick={e => {
                          e.stopPropagation();
                          onOpenPostponeModal(nextSession);
                        }}
                        className="px-2 py-0.5 text-[10px] font-bold bg-amber-600 text-white rounded hover:bg-amber-700 shrink-0 cursor-pointer"
                      >
                        تأجيل الجلسة
                      </button>
                    </div>
                  )}
                </div>

                {/* Bottom Bar: Fees and Open Button */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[11px] text-slate-400 block">إجمالي الأتعاب</span>
                    <span className="font-extrabold text-slate-900 dark:text-white tabular-nums">
                      {formatCurrency(c.totalFee)}
                    </span>
                  </div>

                  <button
                    onClick={() => onSelectCase(c)}
                    className="px-3.5 py-1.5 text-xs font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <span>تفاصيل الملف</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
