import React, { useState, useMemo } from 'react';
import {
  FolderOpen,
  FileText,
  Upload,
  Camera,
  Search,
  Filter,
  Share2,
  Printer,
  Download,
  Eye,
  CheckCircle,
  MessageSquare,
  Shield,
  Plus,
} from 'lucide-react';
import { CaseDocument, CaseItem } from '../types/legal';
import { formatDateArabic, createWhatsAppUrl } from '../utils/storage';

interface DocumentsViewProps {
  documents: CaseDocument[];
  cases: CaseItem[];
  onOpenNewDocument: (caseId?: string) => void;
  onSelectCase: (caseItem: CaseItem) => void;
}

export const DocumentsView: React.FC<DocumentsViewProps> = ({
  documents,
  cases,
  onOpenNewDocument,
  onSelectCase,
}) => {
  const [selectedCaseId, setSelectedCaseId] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [previewDoc, setPreviewDoc] = useState<CaseDocument | null>(null);

  const getCase = (caseId: string) => cases.find(c => c.id === caseId);

  const filteredDocs = useMemo(() => {
    return documents.filter(doc => {
      const matchCase = selectedCaseId === 'all' || doc.caseId === selectedCaseId;
      const matchType = selectedType === 'all' || doc.docType === selectedType;
      const matchSearch =
        searchQuery === '' ||
        doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (doc.powerOfAttorneyNumber && doc.powerOfAttorneyNumber.includes(searchQuery)) ||
        (doc.notes && doc.notes.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchCase && matchType && matchSearch;
    });
  }, [documents, selectedCaseId, selectedType, searchQuery]);

  const handleShareWhatsApp = (doc: CaseDocument) => {
    const parentCase = getCase(doc.caseId);
    if (!parentCase?.clientPhone) return;

    const message = `السلام عليكم ورحمة الله،
أستاذ/ة ${parentCase.clientName}،
مرفق لسيادتكم مستند من ملف قضيتكم رقم (${parentCase.caseNumber} لسنة ${parentCase.year}):
- المستند: ${doc.title} (${doc.docType})
- تاريخ الإيداع: ${formatDateArabic(doc.uploadedAt)}
مكتب المحاماة والاستشارات القانونية.`;

    window.open(createWhatsAppUrl(parentCase.clientPhone, message), '_blank');
  };

  return (
    <div className="space-y-5">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-amber-600" />
            <span>الأرشيف الإلكتروني ومجلدات المستندات ({filteredDocs.length})</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            فهرسة التوكيلات، عرائض الدعاوى، مذكرات الدفاع، وتقارير الخبراء مع إمكانية المشاركة والمسح الضوئي
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4 text-amber-600" />
            <span>طباعة فهرس الأرشيف</span>
          </button>

          <button
            onClick={() => onOpenNewDocument()}
            className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:scale-95 rounded-xl shadow-sm shadow-amber-600/20 flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>رفع مستند / مسح ضوئي</span>
          </button>
        </div>
      </div>

      {/* Filter and Folder Bar */}
      <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
            <input
              type="text"
              placeholder="ابحث بعنوان المستند، رقم التوكيل، أو الكلمات المفتاحية..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 dark:text-white"
            />
          </div>

          {/* Folder / Case filter */}
          <select
            value={selectedCaseId}
            onChange={e => setSelectedCaseId(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg dark:text-white"
          >
            <option value="all">جميع مجلدات القضايا</option>
            {cases.map(c => (
              <option key={c.id} value={c.id}>
                مجلد: قضية {c.caseNumber}/{c.year} - {c.clientName}
              </option>
            ))}
          </select>

          {/* Doc Type filter */}
          <select
            value={selectedType}
            onChange={e => setSelectedType(e.target.value)}
            className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg dark:text-white"
          >
            <option value="all">جميع أنواع المستندات</option>
            <option value="توكيل رسمي">توكيلات رسمية</option>
            <option value="صحيفة دعوى / عريضة">عرائض دعاوى</option>
            <option value="مذكرة دفاع">مذكرات دفاع</option>
            <option value="محضر شرطة">محاضر شرطة</option>
            <option value="حكم قضائي">أحكام قضائية</option>
            <option value="تقرير خبير">تقارير خبراء</option>
            <option value="مستند إثبات / عقد">عقود ومستندات</option>
            <option value="أخرى">أخرى</option>
          </select>
        </div>
      </div>

      {/* Documents Grid */}
      {filteredDocs.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <FolderOpen className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <p className="text-xs text-slate-400">لا توجد وثائق مطابقة لخيارات الفلترة</p>
          <button
            onClick={() => onOpenNewDocument()}
            className="mt-3 text-xs font-bold text-amber-600 hover:underline"
          >
            + رفع مستند جديد بالأرشيف
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocs.map(doc => {
            const parentCase = getCase(doc.caseId);

            return (
              <div
                key={doc.id}
                className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-600 transition-all shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0">
                        <FileText className="w-4 h-4" />
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-400">
                        {doc.docType}
                      </span>
                    </div>

                    <span className="text-[11px] text-slate-400 font-mono">
                      {doc.uploadedAt}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1 mb-1">
                    {doc.title}
                  </h3>

                  {parentCase && (
                    <p className="text-xs text-amber-700 dark:text-amber-400 mb-2 font-medium">
                      ملف: قضية {parentCase.caseNumber}/{parentCase.year} ({parentCase.clientName})
                    </p>
                  )}

                  {doc.powerOfAttorneyNumber && (
                    <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-600 dark:text-slate-300 mb-2">
                      <span className="font-semibold">رقم التوكيل:</span> {doc.powerOfAttorneyNumber}
                      {doc.notaryOffice && <div>{doc.notaryOffice}</div>}
                    </div>
                  )}

                  {doc.notes && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-3">
                      {doc.notes}
                    </p>
                  )}
                </div>

                {/* Footer Controls: Preview, Share WhatsApp, Download */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <div className="text-[11px] text-slate-400 truncate max-w-[130px]">
                    {doc.fileName || 'ملف رقمي'}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setPreviewDoc(doc)}
                      title="معاينة المستند"
                      className="p-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleShareWhatsApp(doc)}
                      title="مشاركة مع الموكل عبر واتساب"
                      className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Document Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-right max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {previewDoc.title}
                </h3>
                <span className="text-xs text-amber-600 font-semibold">
                  {previewDoc.docType} · تاريخ الإيداع: {formatDateArabic(previewDoc.uploadedAt)}
                </span>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4">
              {previewDoc.fileData ? (
                <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-950 p-2 text-center">
                  <img
                    src={previewDoc.fileData}
                    alt={previewDoc.title}
                    className="max-h-96 mx-auto object-contain rounded"
                  />
                </div>
              ) : (
                <div className="p-8 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-center">
                  <FileText className="w-16 h-16 text-amber-600 mx-auto mb-2 opacity-80" />
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
                    {previewDoc.fileName}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    الحجم: {previewDoc.fileSize || '1.2 MB'} · مشفر بالأرشيف الرقمي
                  </p>
                </div>
              )}

              {previewDoc.powerOfAttorneyNumber && (
                <div className="p-3 bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-xl text-xs space-y-1">
                  <p><strong>بيان التوكيل:</strong> {previewDoc.powerOfAttorneyNumber}</p>
                  <p><strong>مكتب التوثيق:</strong> {previewDoc.notaryOffice}</p>
                </div>
              )}

              {previewDoc.notes && (
                <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs">
                  <p className="font-semibold text-slate-700 dark:text-slate-300 mb-0.5">ملاحظات الأرشيف:</p>
                  <p className="text-slate-600 dark:text-slate-400">{previewDoc.notes}</p>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-amber-600" />
                <span>طباعة المستند</span>
              </button>
              <button
                onClick={() => handleShareWhatsApp(previewDoc)}
                className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>إرسال للموكل عبر واتساب</span>
              </button>
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 rounded-xl"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
