import React from 'react';
import {
  Calendar,
  Clock,
  Briefcase,
  DollarSign,
  Users,
  Plus,
  Printer,
  History,
  MessageSquare,
  Scale,
  ChevronLeft,
  Phone,
  Award,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import {
  CaseItem,
  CourtSession,
  PaymentRecord,
  ConsultationItem,
  LawFirmProfile,
} from '../types/legal';
import { formatDateArabic, formatCurrency, createWhatsAppUrl } from '../utils/storage';
import { NavTab } from './Navbar';

interface DashboardViewProps {
  cases: CaseItem[];
  sessions: CourtSession[];
  payments: PaymentRecord[];
  consultations: ConsultationItem[];
  firmProfile: LawFirmProfile;
  onNavigateTab: (tab: NavTab) => void;
  onSelectCase: (caseItem: CaseItem) => void;
  onOpenNewCase: () => void;
  onOpenPostponeModal: (session: CourtSession) => void;
  onOpenNewPayment: () => void;
  onOpenAiDraft: (caseItem?: CaseItem) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  cases,
  sessions,
  payments,
  consultations,
  firmProfile,
  onNavigateTab,
  onSelectCase,
  onOpenNewCase,
  onOpenPostponeModal,
  onOpenNewPayment,
  onOpenAiDraft,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  // Sessions today and tomorrow
  const todaySessions = sessions.filter(s => s.sessionDate === todayStr);
  const tomorrowSessions = sessions.filter(s => s.sessionDate === tomorrowStr);

  // Financial summary
  const totalAgreed = cases.reduce((acc, c) => acc + (c.totalFee || 0), 0);
  const totalCollected = payments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const totalDues = Math.max(0, totalAgreed - totalCollected);

  // Active cases count
  const activeCasesCount = cases.filter(c => c.status === 'جارية' || c.status === 'مؤجلة').length;

  // Upcoming sessions sorted by date
  const upcomingSessions = sessions
    .filter(s => s.sessionDate >= todayStr)
    .sort((a, b) => new Date(a.sessionDate).getTime() - new Date(b.sessionDate).getTime())
    .slice(0, 6);

  const getCaseById = (caseId: string) => cases.find(c => c.id === caseId);

  const handlePrintDashboardReport = () => {
    window.print();
  };

  const logoSrc = firmProfile.logoUrl || '/assets/aistudio/____________________________a39fbca1.png';

  return (
    <div className="space-y-6">
      
      {/* Executive Official Law Office Banner with Photo Background */}
      <div className="relative rounded-2xl overflow-hidden border border-amber-500/30 shadow-xl bg-slate-950 text-white">
        
        {/* Ambient Photo Backdrop */}
        <div className="absolute inset-0 z-0 opacity-25 mix-blend-luminosity overflow-hidden">
          <img
            src={logoSrc}
            alt={firmProfile.firmName}
            className="w-full h-full object-cover object-center filter blur-xs scale-105"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/90 to-amber-950/80 z-0" />

        {/* Banner Content */}
        <div className="relative z-10 p-5 sm:p-7 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            {/* Board Logo Card */}
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-xl shrink-0 bg-slate-900">
              <img
                src={logoSrc}
                alt={firmProfile.firmName}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-amber-500 text-slate-950 flex items-center gap-1 shadow-xs">
                  <Award className="w-3.5 h-3.5" />
                  <span>15 عاماً من الخبرة</span>
                </span>
                <span className="text-xs text-amber-200">
                  {firmProfile.barNumber}
                </span>
              </div>

              <h1 className="text-xl sm:text-2xl font-black text-white leading-tight">
                {firmProfile.firmName}
              </h1>

              <p className="text-xs sm:text-sm text-amber-300 font-semibold">
                {firmProfile.slogan || 'في خدمة العدالة والدفاع عن حقوقكم .. معكم في كل قضية'}
              </p>

              {/* Contact Phones Strip */}
              <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-300">
                <a
                  href={`tel:${firmProfile.phone}`}
                  className="flex items-center gap-1.5 hover:text-amber-400 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-amber-500" />
                  <span className="font-mono font-bold">{firmProfile.phone}</span>
                </a>
                {firmProfile.secondaryPhone && (
                  <a
                    href={`tel:${firmProfile.secondaryPhone}`}
                    className="flex items-center gap-1.5 hover:text-amber-400 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5 text-amber-500" />
                    <span className="font-mono font-bold">{firmProfile.secondaryPhone}</span>
                  </a>
                )}
                <span className="hidden md:inline text-slate-500">·</span>
                <span className="text-slate-400">{firmProfile.email}</span>
              </div>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex flex-wrap items-center gap-2 self-stretch lg:self-auto justify-end shrink-0 no-print">
            <button
              onClick={handlePrintDashboardReport}
              className="px-3.5 py-2 text-xs font-bold bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span>طباعة تقرير المكتب</span>
            </button>

            <button
              onClick={onOpenNewCase}
              className="px-4 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 active:scale-95 rounded-xl transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>تسجيل قضية جديدة</span>
            </button>
          </div>

        </div>

        {/* Specialization Tags Strip */}
        <div className="relative z-10 bg-slate-950/80 border-t border-amber-500/20 px-5 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-amber-400">التخصصات القضائية:</span>
            {firmProfile.specializations?.map(spec => (
              <span key={spec} className="px-2.5 py-0.5 rounded-lg bg-slate-800 text-amber-200 border border-amber-500/20 text-[11px]">
                {spec}
              </span>
            ))}
          </div>

          <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>نظام سحابي مشفر متصل بجميع أجهزتك</span>
          </div>
        </div>

      </div>

      {/* 4 Metric KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Active cases */}
        <div
          onClick={() => onNavigateTab('cases')}
          className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-600 transition-all cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">القضايا المتداولة</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-600 flex items-center justify-center">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {activeCasesCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span>إجمالي المقيد: {cases.length} قضية</span>
            <ChevronLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Today's Court Sessions */}
        <div
          onClick={() => onNavigateTab('docket')}
          className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-600 transition-all cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">جلسات اليوم بالمحكمة</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 tabular-nums">
            {todaySessions.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span>غداً: {tomorrowSessions.length} جلسة</span>
            <ChevronLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Remaining Fees */}
        <div
          onClick={() => onNavigateTab('financials')}
          className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-600 transition-all cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">أتعاب متبقية مستحقة</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700 dark:text-emerald-400 tabular-nums">
            {formatCurrency(totalDues)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span>المحصل: {formatCurrency(totalCollected)}</span>
            <ChevronLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Consultations this week */}
        <div
          onClick={() => onNavigateTab('clients')}
          className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-600 transition-all cursor-pointer shadow-xs group"
        >
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">استشارات المكتب المقررة</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-950/40 text-purple-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {consultations.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span>تنظيم المواعيد ومنع التضارب</span>
            <ChevronLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" />
          </div>
        </div>

      </div>

      {/* Main Grid: Clean State / Upcoming Hearings */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Upcoming Court Hearings (2 Cols) */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                رول وجلسات المحاكم القادمة بالأجندة
              </h3>
            </div>
            
            <div className="flex items-center gap-2 no-print">
              <button
                onClick={handlePrintDashboardReport}
                className="px-2.5 py-1 text-xs text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg flex items-center gap-1 border border-slate-200 dark:border-slate-700"
              >
                <Printer className="w-3.5 h-3.5 text-amber-600" />
                <span>طباعة</span>
              </button>
              <button
                onClick={() => onNavigateTab('docket')}
                className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>كامل الرول</span>
                <ChevronLeft className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="space-y-2.5">
            {upcomingSessions.length === 0 ? (
              <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800">
                <Calendar className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  الأجندة جاهزة وخالية لبدء تسجيل قضاياك الحقيقية
                </h4>
                <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                  تم إفراغ كافة البيانات التجريبية بناءً على طلبك. يمكنك الآن قيد أول قضية أو جلسة وسيتم مزامنتها فوراً مع كافة أجهزتك (الكمبيوتر والموبايل).
                </p>
                <button
                  onClick={onOpenNewCase}
                  className="mt-4 px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-sm"
                >
                  + تسجيل أول قضية الآن
                </button>
              </div>
            ) : (
              upcomingSessions.map(sess => {
                const c = getCaseById(sess.caseId);
                const isToday = sess.sessionDate === todayStr;
                const isTomorrow = sess.sessionDate === tomorrowStr;

                return (
                  <div
                    key={sess.id}
                    className={`p-3.5 rounded-xl border transition-all bg-white dark:bg-slate-900 ${
                      isToday
                        ? 'border-amber-400 dark:border-amber-600 bg-amber-50/20 shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                            {formatDateArabic(sess.sessionDate)}
                          </span>
                          {isToday && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-600 text-white">
                              اليوم
                            </span>
                          )}
                          {isTomorrow && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-600 text-white">
                              غداً
                            </span>
                          )}
                          {sess.sessionTime && (
                            <span className="text-xs text-slate-400 font-mono">
                              {sess.sessionTime}
                            </span>
                          )}
                        </div>

                        {c && (
                          <div className="mt-1 text-xs text-slate-600 dark:text-slate-300">
                            <span className="font-bold text-amber-700 dark:text-amber-400">
                              قضية {c.caseNumber}/{c.year} ({c.caseType})
                            </span>{' '}
                            · {c.court} {sess.courtroom && `· ${sess.courtroom}`}
                          </div>
                        )}

                        <div className="mt-1 text-xs text-slate-800 dark:text-slate-200">
                          <strong className="text-slate-500">القرار / السبب:</strong>{' '}
                          {sess.decisionOrReason}
                        </div>
                      </div>

                      {/* Action: Postpone Button */}
                      <div className="flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800 no-print">
                        <button
                          onClick={() => onOpenPostponeModal(sess)}
                          className="px-3 py-1.5 text-xs font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 rounded-lg border border-amber-200 dark:border-amber-800 flex items-center gap-1.5 cursor-pointer"
                        >
                          <History className="w-3.5 h-3.5" />
                          <span>تأجيل الجلسة</span>
                        </button>

                        {c && (
                          <button
                            onClick={() => onSelectCase(c)}
                            className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer"
                          >
                            عرض القضية
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Office Consultations & Direct Actions */}
        <div className="space-y-4">
          
          {/* Consultations Card */}
          <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Users className="w-4 h-4 text-purple-600" />
                <span>مواعيد المقابلات والاستشارات</span>
              </h4>
              <button
                onClick={() => onNavigateTab('clients')}
                className="text-[11px] font-bold text-amber-600 hover:underline"
              >
                إدارة
              </button>
            </div>

            {consultations.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-3 text-center">
                لا توجد مواعيد استشارات مسجلة حالياً
              </p>
            ) : (
              <div className="space-y-2">
                {consultations.slice(0, 3).map(con => (
                  <div
                    key={con.id}
                    className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 text-xs flex flex-col gap-1 border border-slate-100 dark:border-slate-800"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-800 dark:text-slate-200">{con.clientName}</span>
                      <span className="text-[11px] font-mono text-purple-600 dark:text-purple-400">
                        {con.time} · {con.date}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{con.topic}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                      <span>رسم: {formatCurrency(con.fee)}</span>
                      <span className={con.isPaid ? 'text-emerald-600' : 'text-amber-600'}>
                        {con.isPaid ? 'مدفوع' : 'غير مدفوع'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Direct WhatsApp Client Connect */}
          <div className="p-4 rounded-xl bg-slate-900 text-white space-y-3 shadow-md border border-amber-500/30">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400">خطوط التواصل المباشر</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">المكتب نشط</span>
            </div>
            
            <p className="text-xs text-slate-300">
              يمكنك التواصل مباشرة أو إرسال تقارير الجلسات للموكلين عبر أرقام المكتب المعتمدة:
            </p>

            <div className="space-y-1.5 text-xs font-mono font-bold">
              <a
                href={createWhatsAppUrl(firmProfile.phone, 'تحية طيبة من مكتب الأستاذ إسلام عمر قرني:')}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 flex items-center justify-between text-emerald-400 transition-colors"
              >
                <span>واتساب 1: {firmProfile.phone}</span>
                <MessageSquare className="w-4 h-4" />
              </a>

              {firmProfile.secondaryPhone && (
                <a
                  href={createWhatsAppUrl(firmProfile.secondaryPhone, 'تحية طيبة من مكتب الأستاذ إسلام عمر قرني:')}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 flex items-center justify-between text-emerald-400 transition-colors"
                >
                  <span>واتساب 2: {firmProfile.secondaryPhone}</span>
                  <MessageSquare className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
