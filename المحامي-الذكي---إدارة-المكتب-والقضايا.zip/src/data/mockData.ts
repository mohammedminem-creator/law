import {
  CaseItem,
  CourtSession,
  CaseDocument,
  PaymentRecord,
  ExpenseRecord,
  ClientItem,
  ConsultationItem,
  LawFirmProfile,
  SecuritySettings,
} from '../types/legal';

// Lawyer office profile extracted from the official board photo
export const initialProfile: LawFirmProfile = {
  lawyerName: 'الأستاذ / إسلام عمر قرني',
  title: 'محامٍ - 15 عاماً من الخبرة',
  firmName: 'مكتب محاماه الأستاذ / إسلام عمر قرني',
  phone: '01006580460',
  secondaryPhone: '01558866646',
  email: 'eslam.omar.law@gmail.com',
  address: 'جمهورية مصر العربية',
  barNumber: 'مقيد بنقابة المحامين',
  slogan: 'في خدمة العدالة والدفاع عن حقوقكم .. معكم في كل قضية',
  experienceYears: 15,
  specializations: [
    'قضايا مدنية',
    'قضايا جنائية',
    'أحوال شخصية',
    'استشارات قانونية',
  ],
  logoUrl: '/assets/aistudio/____________________________a39fbca1.png',
};

export const initialSecuritySettings: SecuritySettings = {
  pinEnabled: false,
  pinCode: '1234',
  autoLockMinutes: 15,
};

// Clean start for production as requested:
export const initialCases: CaseItem[] = [];
export const initialSessions: CourtSession[] = [];
export const initialDocuments: CaseDocument[] = [];
export const initialPayments: PaymentRecord[] = [];
export const initialExpenses: ExpenseRecord[] = [];
export const initialClients: ClientItem[] = [];
export const initialConsultations: ConsultationItem[] = [];

// Helper for dynamic dates relative to current date (if demo samples are re-loaded)
export const getRelativeDate = (offsetDays: number): string => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split('T')[0];
};

// Optional sample seed data if ever explicitly requested from settings
export const demoSampleCases: CaseItem[] = [
  {
    id: 'case-demo-1',
    caseNumber: '1042',
    year: 2026,
    caseType: 'جنح',
    court: 'محكمة جنح مدينة نصر',
    circuit: 'دائرة الجنح المستأنفة - الدائرة 4',
    judgeName: 'المستشار رئيس الدائرة',
    clientName: 'أحمد محمود السعيد',
    clientPhone: '01006580460',
    clientRole: 'متهم',
    opponentName: 'شركة النور للاستيراد',
    opponentLawyer: 'الأستاذ كمال الدين',
    subject: 'جنحة شيك، ودفع بالوفاء وانقضاء الدعوى بالصلح',
    status: 'جارية',
    notes: 'تم تقديم مخالصة موثقة بالشهر العقاري.',
    totalFee: 35000,
    createdAt: getRelativeDate(-10),
    updatedAt: getRelativeDate(0),
  },
];
