export type CaseType =
  | 'جنايات'
  | 'جنح'
  | 'مدني كلي'
  | 'مدني جزئي'
  | 'أسرة (أحوال شخصية)'
  | 'تجاري وإفلاس'
  | 'عمالي'
  | 'مجلس الدولة (قضاء إداري)'
  | 'محكمة النقض'
  | 'محكمة الاستئناف'
  | 'محكمة تنفيذ'
  | 'أمور وقتية ومستعجلة'
  | 'قضايا عسكرية'
  | 'أخرى';

export type CaseStatus = 'جارية' | 'مؤجلة' | 'محكومة' | 'مشطوبة' | 'صلح' | 'محفوظة';

export type ClientRole =
  | 'مدعي'
  | 'مدعى عليه'
  | 'مجني عليه'
  | 'متهم'
  | 'طالب'
  | 'مطلوب ضده'
  | 'مستأنِف'
  | 'مستأنَف ضده'
  | 'طاعن'
  | 'مطعون ضده'
  | 'شاكي'
  | 'مشكو في حقه';

export interface PostponementRecord {
  id: string;
  fromDate: string;
  toDate: string;
  reason: string;
  postponedAt: string;
  notes?: string;
}

export interface CourtSession {
  id: string;
  caseId: string;
  sessionDate: string; // YYYY-MM-DD
  sessionTime?: string; // HH:mm
  courtroom?: string; // قاعة المحكمة / رقم القاعة
  chamber?: string; // الدائرة
  rollNumber?: number; // رقم الرول في الجلسة
  decisionOrReason: string; // سبب الجلسة أو القرار (مثلاً: للاطلاع والمستندات، لحضور المتهم، لإعادة الإعلان، للمرافعة، للحكم)
  isCompleted: boolean;
  postponementHistory: PostponementRecord[];
  lawyerNotes?: string;
  reminderSent?: boolean;
}

export interface CaseDocument {
  id: string;
  caseId: string;
  title: string;
  docType:
    | 'توكيل رسمي'
    | 'صحيفة دعوى / عريضة'
    | 'مذكرة دفاع'
    | 'محضر شرطة'
    | 'حكم قضائي'
    | 'تقرير خبير'
    | 'مستند إثبات / عقد'
    | 'إنذار رسمي'
    | 'إيصال سداد'
    | 'أخرى';
  powerOfAttorneyNumber?: string;
  notaryOffice?: string;
  date?: string;
  fileData?: string; // Base64 data URL or mock file path
  fileName: string;
  fileSize?: string;
  uploadedAt: string;
  notes?: string;
}

export interface PaymentRecord {
  id: string;
  caseId: string;
  amount: number;
  date: string;
  paymentMethod: 'نقدي' | 'تحويل بنكي' | 'شيك مصرفي' | 'محفظة إلكترونية / إنستاباي';
  receiptNumber: string;
  receivedBy: string;
  notes?: string;
}

export interface ExpenseRecord {
  id: string;
  caseId: string;
  title: string;
  amount: number;
  date: string;
  category:
    | 'رسوم قضائية'
    | 'دمغات وتوكيلات'
    | 'إعلانات وتكاليف محضّرين'
    | 'انتقالات وسفر'
    | 'تصوير ونسخ مستندات'
    | 'أتعاب خبراء'
    | 'أخرى';
  receiptImageUrl?: string;
  notes?: string;
}

export interface CaseItem {
  id: string;
  caseNumber: string;
  year: number;
  caseType: CaseType;
  court: string;
  circuit?: string; // الدائرة (مثل: الدائرة 5 مدني، الدائرة 3 جنايات شمال)
  judgeName?: string;
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  clientRole: ClientRole;
  clientAddress?: string;
  opponentName: string;
  opponentLawyer?: string;
  opponentPhone?: string;
  subject: string; // موضوع الدعوى
  status: CaseStatus;
  notes?: string;
  totalFee: number; // إجمالي الأتعاب المتفق عليها
  createdAt: string;
  updatedAt: string;
}

export interface ClientItem {
  id: string;
  name: string;
  phone: string;
  email?: string;
  nationalId?: string; // الرقم القومي / بطاقة الهوية
  address?: string;
  companyName?: string;
  notes?: string;
  createdAt: string;
}

export interface ConsultationItem {
  id: string;
  clientName: string;
  phone: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  durationMinutes: number;
  fee: number;
  isPaid: boolean;
  topic: string;
  status: 'مؤكدة' | 'معلقة' | 'ملغاة' | 'منتهية';
  notes?: string;
}

export interface LawFirmProfile {
  lawyerName: string;
  title: string;
  firmName: string;
  phone: string;
  secondaryPhone?: string;
  email: string;
  address: string;
  barNumber: string; // رقم القيد بنقابة المحامين
  taxNumber?: string;
  slogan?: string;
  experienceYears?: number;
  specializations?: string[];
  logoUrl?: string;
}

export interface SecuritySettings {
  pinEnabled: boolean;
  pinCode: string; // 4 digits
  autoLockMinutes: number;
}
