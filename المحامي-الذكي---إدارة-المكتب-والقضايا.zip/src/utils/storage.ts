import {
  CaseItem,
  CourtSession,
  CaseDocument,
  PaymentRecord,
  ExpenseRecord,
  ClientItem,
  ConsultationItem,
  LawFirmProfile,
  SecuritySettings,
} from '../types/legal';
import {
  initialProfile,
  initialSecuritySettings,
  initialCases,
  initialSessions,
  initialDocuments,
  initialPayments,
  initialExpenses,
  initialClients,
  initialConsultations,
} from '../data/mockData';

const STORAGE_KEYS = {
  CASES: 'lawyer_app_cases_v2',
  SESSIONS: 'lawyer_app_sessions_v2',
  DOCUMENTS: 'lawyer_app_documents_v2',
  PAYMENTS: 'lawyer_app_payments_v2',
  EXPENSES: 'lawyer_app_expenses_v2',
  CLIENTS: 'lawyer_app_clients_v2',
  CONSULTATIONS: 'lawyer_app_consultations_v2',
  PROFILE: 'lawyer_app_profile_v2',
  SECURITY: 'lawyer_app_security_v2',
  VERSION: 'lawyer_app_version_v2',
};

export interface AppStateData {
  cases: CaseItem[];
  sessions: CourtSession[];
  documents: CaseDocument[];
  payments: PaymentRecord[];
  expenses: ExpenseRecord[];
  clients: ClientItem[];
  consultations: ConsultationItem[];
  profile: LawFirmProfile;
  security: SecuritySettings;
  version?: number;
  lastModified?: string;
}

export function loadAppState(): AppStateData {
  try {
    const cases = localStorage.getItem(STORAGE_KEYS.CASES);
    const sessions = localStorage.getItem(STORAGE_KEYS.SESSIONS);
    const documents = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
    const payments = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    const expenses = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    const clients = localStorage.getItem(STORAGE_KEYS.CLIENTS);
    const consultations = localStorage.getItem(STORAGE_KEYS.CONSULTATIONS);
    const profile = localStorage.getItem(STORAGE_KEYS.PROFILE);
    const security = localStorage.getItem(STORAGE_KEYS.SECURITY);
    const version = localStorage.getItem(STORAGE_KEYS.VERSION);

    return {
      cases: cases ? JSON.parse(cases) : initialCases,
      sessions: sessions ? JSON.parse(sessions) : initialSessions,
      documents: documents ? JSON.parse(documents) : initialDocuments,
      payments: payments ? JSON.parse(payments) : initialPayments,
      expenses: expenses ? JSON.parse(expenses) : initialExpenses,
      clients: clients ? JSON.parse(clients) : initialClients,
      consultations: consultations ? JSON.parse(consultations) : initialConsultations,
      profile: profile ? JSON.parse(profile) : initialProfile,
      security: security ? JSON.parse(security) : initialSecuritySettings,
      version: version ? Number(version) : 1,
    };
  } catch (err) {
    console.error('Error loading app state from localStorage:', err);
    return {
      cases: initialCases,
      sessions: initialSessions,
      documents: initialDocuments,
      payments: initialPayments,
      expenses: initialExpenses,
      clients: initialClients,
      consultations: initialConsultations,
      profile: initialProfile,
      security: initialSecuritySettings,
      version: 1,
    };
  }
}

export function saveAppState(state: AppStateData): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CASES, JSON.stringify(state.cases));
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(state.sessions));
    localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(state.documents));
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(state.payments));
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(state.expenses));
    localStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(state.clients));
    localStorage.setItem(STORAGE_KEYS.CONSULTATIONS, JSON.stringify(state.consultations));
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(state.profile));
    localStorage.setItem(STORAGE_KEYS.SECURITY, JSON.stringify(state.security));
    if (state.version) {
      localStorage.setItem(STORAGE_KEYS.VERSION, String(state.version));
    }
  } catch (err) {
    console.error('Error saving app state to localStorage:', err);
  }
}

// Multi-Device Server Sync APIs
export async function fetchServerState(): Promise<AppStateData | null> {
  try {
    const res = await fetch('/api/data');
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch (err) {
    console.warn('Could not fetch server state (offline?):', err);
    return null;
  }
}

export async function pushServerState(state: AppStateData): Promise<{ version: number; lastModified: string } | null> {
  try {
    const res = await fetch('/api/data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: state }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.warn('Could not push server state:', err);
    return null;
  }
}

export async function checkServerVersion(): Promise<number | null> {
  try {
    const res = await fetch('/api/data/version');
    if (!res.ok) return null;
    const json = await res.json();
    return json.version;
  } catch {
    return null;
  }
}

export function exportBackup(state: AppStateData): void {
  const exportData = {
    appName: 'مكتب محاماه الأستاذ / إسلام عمر قرني',
    version: '2.0.0',
    exportedAt: new Date().toISOString(),
    data: state,
  };
  const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
    JSON.stringify(exportData, null, 2)
  )}`;
  const downloadAnchor = document.createElement('a');
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
  const timeStr = `${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
  downloadAnchor.setAttribute('href', jsonString);
  downloadAnchor.setAttribute('download', `eslam_omar_korany_law_backup_${dateStr}_${timeStr}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function resetToDefaults(): AppStateData {
  const defaultState: AppStateData = {
    cases: initialCases,
    sessions: initialSessions,
    documents: initialDocuments,
    payments: initialPayments,
    expenses: initialExpenses,
    clients: initialClients,
    consultations: initialConsultations,
    profile: initialProfile,
    security: initialSecuritySettings,
    version: 1,
    lastModified: new Date().toISOString(),
  };
  saveAppState(defaultState);
  pushServerState(defaultState);
  return defaultState;
}

export function formatCurrency(amount: number): string {
  return (
    new Intl.NumberFormat('ar-EG', {
      style: 'decimal',
      maximumFractionDigits: 0,
    }).format(amount) + ' ج.م'
  );
}

export function formatDateArabic(dateStr: string): string {
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
      return d.toLocaleDateString('ar-EG', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    }
    return dateStr;
  } catch {
    return dateStr;
  }
}

export function createWhatsAppUrl(phone: string, text: string): string {
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.startsWith('01') && cleanPhone.length === 11) {
    cleanPhone = '2' + cleanPhone;
  }
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
}
