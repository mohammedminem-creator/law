/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  loadAppState,
  saveAppState,
  resetToDefaults,
  fetchServerState,
  pushServerState,
  checkServerVersion,
  AppStateData,
} from './utils/storage';
import {
  CaseItem,
  CourtSession,
  CaseDocument,
  PaymentRecord,
  ExpenseRecord,
  ClientItem,
  ConsultationItem,
  LawFirmProfile,
  SecuritySettings,
} from './types/legal';
import { Navbar, NavTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { CasesView } from './components/CasesView';
import { DocketView } from './components/DocketView';
import { DocumentsView } from './components/DocumentsView';
import { FinancialsView } from './components/FinancialsView';
import { ClientsView } from './components/ClientsView';
import { AiLegalAssistantView } from './components/AiLegalAssistantView';
import { SettingsAndBackupView } from './components/SettingsAndBackupView';
import { PinLockModal } from './components/PinLockModal';
import { PostponeSessionModal } from './components/PostponeSessionModal';
import { NewCaseModal } from './components/NewCaseModal';
import { CaseDetailsModal } from './components/CaseDetailsModal';
import { ReceiptPrintModal } from './components/ReceiptPrintModal';
import { NewPaymentModal, NewExpenseModal } from './components/FinanceModals';
import { NewSessionModal } from './components/NewSessionModal';
import { NewDocumentModal } from './components/NewDocumentModal';
import { NewConsultationModal } from './components/NewConsultationModal';

export default function App() {
  // Load initial state (from cache immediately, then syncs with server)
  const [appState, setAppState] = useState<AppStateData>(() => loadAppState());

  // Multi-Device Server Sync tracking
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('');
  const currentVersionRef = useRef<number>(appState.version || 1);
  const isPushingRef = useRef<boolean>(false);

  // Dark Mode State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Online / Offline State
  const [isOnline, setIsOnline] = useState<boolean>(() => navigator.onLine);

  // Security / PIN lock state
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    const saved = loadAppState();
    return saved.security.pinEnabled;
  });

  // Current Navigation Tab
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');

  // Modals state
  const [isNewCaseOpen, setIsNewCaseOpen] = useState(false);
  const [selectedCaseForDetails, setSelectedCaseForDetails] = useState<CaseItem | null>(null);

  // Postponement modal
  const [postponeSession, setPostponeSession] = useState<CourtSession | null>(null);

  // Financial Modals
  const [isNewPaymentOpen, setIsNewPaymentOpen] = useState(false);
  const [defaultPaymentCaseId, setDefaultPaymentCaseId] = useState<string | undefined>(undefined);
  const [isNewExpenseOpen, setIsNewExpenseOpen] = useState(false);
  const [defaultExpenseCaseId, setDefaultExpenseCaseId] = useState<string | undefined>(undefined);

  // Receipt Print Modal
  const [receiptPayment, setReceiptPayment] = useState<PaymentRecord | null>(null);
  const [receiptCase, setReceiptCase] = useState<CaseItem | null>(null);

  // Session & Doc Modals
  const [isNewSessionOpen, setIsNewSessionOpen] = useState(false);
  const [defaultSessionCaseId, setDefaultSessionCaseId] = useState<string | undefined>(undefined);
  const [isNewDocumentOpen, setIsNewDocumentOpen] = useState(false);
  const [defaultDocCaseId, setDefaultDocCaseId] = useState<string | undefined>(undefined);

  // Consultation Modal
  const [isNewConsultationOpen, setIsNewConsultationOpen] = useState(false);

  // AI view prefilled states
  const [aiInitialCaseId, setAiInitialCaseId] = useState<string | undefined>(undefined);
  const [aiInitialAction, setAiInitialAction] = useState<string>('draft_memo');

  // Multi-Device Server Sync Handlers
  const syncWithServer = useCallback(async (forcePull = false) => {
    if (!navigator.onLine) return;
    try {
      setIsSyncing(true);
      const serverVersion = await checkServerVersion();

      if (serverVersion !== null && (serverVersion > currentVersionRef.current || forcePull)) {
        const remoteData = await fetchServerState();
        if (remoteData) {
          currentVersionRef.current = remoteData.version || serverVersion;
          setAppState(remoteData);
          saveAppState(remoteData);
          const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
          setLastSyncTime(time);
        }
      } else {
        const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        setLastSyncTime(time);
      }
    } catch (err) {
      console.warn('Sync failed:', err);
    } finally {
      setIsSyncing(false);
    }
  }, []);

  // Helper to commit state changes locally and push to server for all devices
  const updateAndBroadcastState = useCallback((updater: (prev: AppStateData) => AppStateData) => {
    setAppState(prev => {
      const next = updater(prev);
      saveAppState(next);

      // Push to server asynchronously
      if (!isPushingRef.current && navigator.onLine) {
        isPushingRef.current = true;
        pushServerState(next)
          .then(res => {
            if (res?.version) {
              currentVersionRef.current = res.version;
              const time = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
              setLastSyncTime(time);
            }
          })
          .catch(err => console.warn('Broadcast failed:', err))
          .finally(() => {
            isPushingRef.current = false;
          });
      }

      return next;
    });
  }, []);

  // Initial pull from server and periodic polling for changes made on other devices
  useEffect(() => {
    // Initial fetch on mount
    syncWithServer(true);

    // Polling interval every 3.5 seconds
    const interval = setInterval(() => {
      syncWithServer(false);
    }, 3500);

    // Window focus listener (syncs immediately when lawyer opens/switches tab)
    const handleFocus = () => {
      syncWithServer(false);
    };
    window.addEventListener('focus', handleFocus);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', handleFocus);
    };
  }, [syncWithServer]);

  // Sync dark class on html
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Online / Offline listeners
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      syncWithServer(true);
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [syncWithServer]);

  // Today's court sessions count for alert badges
  const todayStr = new Date().toISOString().split('T')[0];
  const todaySessionsCount = appState.sessions.filter(s => s.sessionDate === todayStr).length;

  // --- Handlers ---

  const handleToggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  const handleLockApp = () => {
    setIsLocked(true);
  };

  const handleUnlockApp = () => {
    setIsLocked(false);
  };

  // Add New Case
  const handleSaveNewCase = (
    newCase: CaseItem,
    initialSession?: CourtSession,
    initialPaymentAmount?: number
  ) => {
    updateAndBroadcastState(prev => {
      const nextCases = [newCase, ...prev.cases];
      const nextSessions = initialSession ? [initialSession, ...prev.sessions] : prev.sessions;

      let nextPayments = prev.payments;
      if (initialPaymentAmount && initialPaymentAmount > 0) {
        const depositReceipt: PaymentRecord = {
          id: 'pay-' + Date.now(),
          caseId: newCase.id,
          amount: initialPaymentAmount,
          date: newCase.createdAt,
          paymentMethod: 'نقدي',
          receiptNumber: `REC-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
          receivedBy: prev.profile.lawyerName,
          notes: 'دفعة مقدم أتعاب عند قيد الدعوى بالأجندة',
        };
        nextPayments = [depositReceipt, ...nextPayments];
      }

      // Add to clients directory if not exists
      let nextClients = prev.clients;
      const clientExists = prev.clients.some(
        c => c.name.trim().toLowerCase() === newCase.clientName.trim().toLowerCase()
      );
      if (!clientExists) {
        const newClient: ClientItem = {
          id: 'client-' + Date.now(),
          name: newCase.clientName,
          phone: newCase.clientPhone,
          email: newCase.clientEmail,
          address: newCase.clientAddress,
          createdAt: newCase.createdAt,
        };
        nextClients = [newClient, ...nextClients];
      }

      return {
        ...prev,
        cases: nextCases,
        sessions: nextSessions,
        payments: nextPayments,
        clients: nextClients,
      };
    });
  };

  // Postpone Session Handler
  const handlePostponeSession = (
    sessionId: string,
    newDate: string,
    reason: string,
    lawyerNotes?: string
  ) => {
    updateAndBroadcastState(prev => {
      const targetSession = prev.sessions.find(s => s.id === sessionId);
      if (!targetSession) return prev;

      const newPostponement = {
        id: 'post-' + Date.now(),
        fromDate: targetSession.sessionDate,
        toDate: newDate,
        reason,
        postponedAt: new Date().toISOString().split('T')[0],
        notes: lawyerNotes,
      };

      const updatedSessions = prev.sessions.map(s => {
        if (s.id === sessionId) {
          return {
            ...s,
            sessionDate: newDate,
            decisionOrReason: reason,
            lawyerNotes: lawyerNotes || s.lawyerNotes,
            postponementHistory: [newPostponement, ...(s.postponementHistory || [])],
          };
        }
        return s;
      });

      // Update case status to 'مؤجلة'
      const updatedCases = prev.cases.map(c => {
        if (c.id === targetSession.caseId && c.status !== 'محكومة' && c.status !== 'صلح') {
          return {
            ...c,
            status: 'مؤجلة' as const,
            updatedAt: new Date().toISOString().split('T')[0],
          };
        }
        return c;
      });

      return {
        ...prev,
        sessions: updatedSessions,
        cases: updatedCases,
      };
    });
  };

  // Add Session Handler
  const handleSaveNewSession = (newSession: CourtSession) => {
    updateAndBroadcastState(prev => ({
      ...prev,
      sessions: [newSession, ...prev.sessions],
    }));
  };

  // Add Document Handler
  const handleSaveNewDocument = (newDoc: CaseDocument) => {
    updateAndBroadcastState(prev => ({
      ...prev,
      documents: [newDoc, ...prev.documents],
    }));
  };

  // Add Payment Handler
  const handleSaveNewPayment = (newPayment: PaymentRecord) => {
    updateAndBroadcastState(prev => ({
      ...prev,
      payments: [newPayment, ...prev.payments],
    }));
  };

  // Add Expense Handler
  const handleSaveNewExpense = (newExpense: ExpenseRecord) => {
    updateAndBroadcastState(prev => ({
      ...prev,
      expenses: [newExpense, ...prev.expenses],
    }));
  };

  // Add Client Handler
  const handleSaveNewClient = (newClient: ClientItem) => {
    updateAndBroadcastState(prev => ({
      ...prev,
      clients: [newClient, ...prev.clients],
    }));
  };

  // Add Consultation Handler
  const handleSaveNewConsultation = (newConsultation: ConsultationItem) => {
    updateAndBroadcastState(prev => ({
      ...prev,
      consultations: [newConsultation, ...prev.consultations],
    }));
  };

  // Update Case Status
  const handleUpdateCaseStatus = (caseId: string, newStatus: CaseItem['status']) => {
    updateAndBroadcastState(prev => ({
      ...prev,
      cases: prev.cases.map(c =>
        c.id === caseId
          ? { ...c, status: newStatus, updatedAt: new Date().toISOString().split('T')[0] }
          : c
      ),
    }));
    if (selectedCaseForDetails && selectedCaseForDetails.id === caseId) {
      setSelectedCaseForDetails(prev => (prev ? { ...prev, status: newStatus } : null));
    }
  };

  // Save AI Generated Document to Case Archive
  const handleSaveDocToCase = (caseId: string, title: string, text: string) => {
    const newDoc: CaseDocument = {
      id: 'doc-ai-' + Date.now(),
      caseId,
      title,
      docType: 'مذكرة دفاع',
      fileName: `${title}.txt`,
      fileSize: '45 KB',
      uploadedAt: new Date().toISOString().split('T')[0],
      notes: 'مسودة محررة بواسطة المساعد القانوني الذكي ومحفوظة بالأرشيف',
    };
    handleSaveNewDocument(newDoc);
  };

  // Trigger Receipt Printing Modal
  const handlePrintReceipt = (payment: PaymentRecord, caseItem: CaseItem) => {
    setReceiptPayment(payment);
    setReceiptCase(caseItem);
  };

  // Navigate to AI Assistant with specific case and action
  const handleOpenAiDraft = (caseItem?: CaseItem, initialAction = 'draft_memo') => {
    if (caseItem) setAiInitialCaseId(caseItem.id);
    setAiInitialAction(initialAction);
    setCurrentTab('ai_assistant');
    if (selectedCaseForDetails) setSelectedCaseForDetails(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-amber-600 selection:text-white relative">
      
      {/* Ambient Executive Watermark Logo from Lawyer Board Photo */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-[0.035] dark:opacity-[0.06] bg-center bg-no-repeat bg-contain"
        style={{
          backgroundImage: `url('${appState.profile.logoUrl || '/assets/aistudio/____________________________a39fbca1.png'}')`,
        }}
      />

      {/* PIN Lock Screen if locked */}
      {isLocked && (
        <PinLockModal
          correctPin={appState.security.pinCode || '1234'}
          onUnlock={handleUnlockApp}
          firmName={appState.profile.firmName}
        />
      )}

      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenNewCase={() => setIsNewCaseOpen(true)}
        onLockApp={handleLockApp}
        isDarkMode={isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
        isOnline={isOnline}
        todaySessionsCount={todaySessionsCount}
        firmProfile={appState.profile}
        isSyncing={isSyncing}
        onManualSync={() => syncWithServer(true)}
        lastSyncTime={lastSyncTime}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-10">
        
        {currentTab === 'dashboard' && (
          <DashboardView
            cases={appState.cases}
            sessions={appState.sessions}
            payments={appState.payments}
            consultations={appState.consultations}
            firmProfile={appState.profile}
            onNavigateTab={setCurrentTab}
            onSelectCase={setSelectedCaseForDetails}
            onOpenNewCase={() => setIsNewCaseOpen(true)}
            onOpenPostponeModal={session => setPostponeSession(session)}
            onOpenNewPayment={() => setIsNewPaymentOpen(true)}
            onOpenAiDraft={handleOpenAiDraft}
          />
        )}

        {currentTab === 'cases' && (
          <CasesView
            cases={appState.cases}
            sessions={appState.sessions}
            onOpenNewCase={() => setIsNewCaseOpen(true)}
            onSelectCase={setSelectedCaseForDetails}
            onOpenPostponeModal={session => setPostponeSession(session)}
          />
        )}

        {currentTab === 'docket' && (
          <DocketView
            sessions={appState.sessions}
            cases={appState.cases}
            firmProfile={appState.profile}
            onOpenPostponeModal={session => setPostponeSession(session)}
            onOpenNewSession={() => {
              setDefaultSessionCaseId(undefined);
              setIsNewSessionOpen(true);
            }}
            onSelectCase={setSelectedCaseForDetails}
          />
        )}

        {currentTab === 'documents' && (
          <DocumentsView
            documents={appState.documents}
            cases={appState.cases}
            onOpenNewDocument={caseId => {
              setDefaultDocCaseId(caseId);
              setIsNewDocumentOpen(true);
            }}
            onSelectCase={setSelectedCaseForDetails}
          />
        )}

        {currentTab === 'financials' && (
          <FinancialsView
            cases={appState.cases}
            payments={appState.payments}
            expenses={appState.expenses}
            firmProfile={appState.profile}
            onOpenNewPayment={caseId => {
              setDefaultPaymentCaseId(caseId);
              setIsNewPaymentOpen(true);
            }}
            onOpenNewExpense={caseId => {
              setDefaultExpenseCaseId(caseId);
              setIsNewExpenseOpen(true);
            }}
            onPrintReceipt={handlePrintReceipt}
            onSelectCase={setSelectedCaseForDetails}
          />
        )}

        {currentTab === 'clients' && (
          <ClientsView
            clients={appState.clients}
            cases={appState.cases}
            consultations={appState.consultations}
            sessions={appState.sessions}
            onOpenNewConsultation={() => setIsNewConsultationOpen(true)}
            onOpenNewClient={handleSaveNewClient}
            onSelectCase={setSelectedCaseForDetails}
          />
        )}

        {currentTab === 'ai_assistant' && (
          <AiLegalAssistantView
            cases={appState.cases}
            firmProfile={appState.profile}
            initialCaseId={aiInitialCaseId}
            initialAction={aiInitialAction}
            onSaveDocToCase={handleSaveDocToCase}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsAndBackupView
            appState={appState}
            firmProfile={appState.profile}
            securitySettings={appState.security}
            onUpdateProfile={p => updateAndBroadcastState(prev => ({ ...prev, profile: p }))}
            onUpdateSecurity={s => updateAndBroadcastState(prev => ({ ...prev, security: s }))}
            onRestoreBackup={imported => {
              setAppState(imported);
              saveAppState(imported);
              pushServerState(imported);
            }}
            onResetDefaults={() => {
              const res = resetToDefaults();
              setAppState(res);
            }}
            isOnline={isOnline}
            onLockScreenNow={handleLockApp}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 text-center text-xs text-slate-500 dark:text-slate-400 no-print relative z-10">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>{appState.profile.firmName} · هاتف: {appState.profile.phone} {appState.profile.secondaryPhone && `· ${appState.profile.secondaryPhone}`}</span>
          <span className="text-[11px] text-slate-400">
            {appState.profile.slogan || 'في خدمة العدالة والدفاع عن حقوقكم .. معكم في كل قضية'}
          </span>
        </div>
      </footer>

      {/* --- Modals --- */}

      {/* New Case Modal */}
      <NewCaseModal
        isOpen={isNewCaseOpen}
        onClose={() => setIsNewCaseOpen(false)}
        onSave={handleSaveNewCase}
      />

      {/* Postpone Session Modal */}
      {postponeSession && (
        <PostponeSessionModal
          isOpen={!!postponeSession}
          session={postponeSession}
          caseItem={appState.cases.find(c => c.id === postponeSession.caseId)}
          onClose={() => setPostponeSession(null)}
          onPostpone={handlePostponeSession}
        />
      )}

      {/* Case Details Modal */}
      {selectedCaseForDetails && (
        <CaseDetailsModal
          caseItem={selectedCaseForDetails}
          sessions={appState.sessions.filter(s => s.caseId === selectedCaseForDetails.id)}
          documents={appState.documents.filter(d => d.caseId === selectedCaseForDetails.id)}
          payments={appState.payments.filter(p => p.caseId === selectedCaseForDetails.id)}
          expenses={appState.expenses.filter(e => e.caseId === selectedCaseForDetails.id)}
          firmProfile={appState.profile}
          isOpen={!!selectedCaseForDetails}
          onClose={() => setSelectedCaseForDetails(null)}
          onOpenPostponeModal={session => setPostponeSession(session)}
          onOpenNewSession={caseId => {
            setDefaultSessionCaseId(caseId);
            setIsNewSessionOpen(true);
          }}
          onOpenNewDocument={caseId => {
            setDefaultDocCaseId(caseId);
            setIsNewDocumentOpen(true);
          }}
          onOpenNewPayment={caseId => {
            setDefaultPaymentCaseId(caseId);
            setIsNewPaymentOpen(true);
          }}
          onOpenNewExpense={caseId => {
            setDefaultExpenseCaseId(caseId);
            setIsNewExpenseOpen(true);
          }}
          onPrintReceipt={handlePrintReceipt}
          onOpenAiDraft={handleOpenAiDraft}
          onUpdateCaseStatus={handleUpdateCaseStatus}
        />
      )}

      {/* Receipt Print Modal */}
      {receiptPayment && receiptCase && (
        <ReceiptPrintModal
          payment={receiptPayment}
          caseItem={receiptCase}
          firmProfile={appState.profile}
          isOpen={!!receiptPayment}
          onClose={() => {
            setReceiptPayment(null);
            setReceiptCase(null);
          }}
          totalPaid={appState.payments
            .filter(p => p.caseId === receiptCase.id)
            .reduce((sum, p) => sum + p.amount, 0)}
        />
      )}

      {/* New Payment Modal */}
      <NewPaymentModal
        cases={appState.cases}
        defaultCaseId={defaultPaymentCaseId}
        isOpen={isNewPaymentOpen}
        onClose={() => setIsNewPaymentOpen(false)}
        onSave={handleSaveNewPayment}
      />

      {/* New Expense Modal */}
      <NewExpenseModal
        cases={appState.cases}
        defaultCaseId={defaultExpenseCaseId}
        isOpen={isNewExpenseOpen}
        onClose={() => setIsNewExpenseOpen(false)}
        onSave={handleSaveNewExpense}
      />

      {/* New Session Modal */}
      <NewSessionModal
        cases={appState.cases}
        defaultCaseId={defaultSessionCaseId}
        isOpen={isNewSessionOpen}
        onClose={() => setIsNewSessionOpen(false)}
        onSave={handleSaveNewSession}
      />

      {/* New Document Modal */}
      <NewDocumentModal
        cases={appState.cases}
        defaultCaseId={defaultDocCaseId}
        isOpen={isNewDocumentOpen}
        onClose={() => setIsNewDocumentOpen(false)}
        onSave={handleSaveNewDocument}
      />

      {/* New Consultation Modal */}
      <NewConsultationModal
        sessions={appState.sessions}
        cases={appState.cases}
        isOpen={isNewConsultationOpen}
        onClose={() => setIsNewConsultationOpen(false)}
        onSave={handleSaveNewConsultation}
      />

    </div>
  );
}
